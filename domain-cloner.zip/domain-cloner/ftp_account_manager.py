import ftplib
import os
import random
import string

class FTPSubdomainManager:
    def __init__(self, cpanel_host, cpanel_username, cpanel_password, cpanel_port=2083):
        self.cpanel_host = cpanel_host
        self.cpanel_username = cpanel_username
        self.cpanel_password = cpanel_password
        self.cpanel_port = cpanel_port
        self.ftp_connections = {}
    
    def generate_ftp_password(self, length=12):
        """Generate a strong FTP password"""
        chars = string.ascii_letters + string.digits + "!@#$%^&*"
        return ''.join(random.choice(chars) for _ in range(length))
    
    def create_ftp_account(self, subdomain, ftp_username=None, ftp_password=None):
        """Create FTP account for subdomain using cPanel UAPI"""
        if not ftp_username:
            ftp_username = f"{self.cpanel_username}_{subdomain.replace('.', '_')}"
        
        if not ftp_password:
            ftp_password = self.generate_ftp_password()
        
        # Create FTP account via UAPI
        params = {
            'user': ftp_username,
            'pass': ftp_password,
            'homedir': f"/home/{self.cpanel_username}/{subdomain}",
            'quota': 0  # Unlimited
        }
        
        success, result = self._make_request("Ftp/add_ftp", params)
        
        if success:
            print(f"✅ Created FTP account: {ftp_username} for {subdomain}")
            return {
                'username': ftp_username,
                'password': ftp_password,
                'host': self.cpanel_host,
                'port': 21
            }
        else:
            print(f"❌ Failed to create FTP account: {result}")
            return None
    
    def connect_ftp(self, subdomain, ftp_credentials):
        """Establish FTP connection for a subdomain"""
        try:
            ftp = ftplib.FTP()
            ftp.connect(ftp_credentials['host'], ftp_credentials['port'])
            ftp.login(ftp_credentials['username'], ftp_credentials['password'])
            
            self.ftp_connections[subdomain] = ftp
            print(f"✅ FTP Connected for {subdomain}")
            return ftp
        except Exception as e:
            print(f"❌ FTP Connection failed for {subdomain}: {e}")
            return None