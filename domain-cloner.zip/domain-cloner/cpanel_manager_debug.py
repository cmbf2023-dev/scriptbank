import requests
from requests.auth import HTTPBasicAuth
import base64

# Your credentials
CPANEL_HOST = "ssic.ng"  # Change this
USERNAME = "ssicng"  # Change this
API_TOKEN = "P24OZRI7GIFSGF1MMDJJHEPYHV2G36ZK"  # Change this

# Build the URL
url = f"https://{CPANEL_HOST}:2083/execute/uapi/SubDomain/listsubdomains"

# Create BasicAuth
def test_all_auth_methods():
    CPANEL_HOST = "ssic.ng"
    USERNAME = "ssicng"
    API_TOKEN = "P24OZRI7GIFSGF1MMDJJHEPYHV2G36ZK"
    
    methods = [
        {
            'name': 'Authorization Header',
            'headers': {'Authorization': f'cpanel {USERNAME}:{API_TOKEN}'},
            'auth': None
        },
        {
            'name': 'Basic Auth with API Token',
            'headers': {},
            'auth': (USERNAME, API_TOKEN)
        },
        {
            'name': 'cPanel Token in URL',
            'headers': {},
            'auth': None,
            'url_extra': f'&cpanel_jsonapi_user={USERNAME}&cpanel_jsonapi_apiversion=2&cpanel_jsonapi_module=SubDomain&cpanel_jsonapi_func=listsubdomains'
        }
    ]
    
    base_url = f"https://{CPANEL_HOST}:2083/execute/SubDomain/listsubdomains"
    
    for method in methods:
        print(f"\n🔧 Testing: {method['name']}")
        
        url = base_url
        if 'url_extra' in method:
            url += method['url_extra']
        
        try:
            response = requests.get(
                url,
                headers=method['headers'],
                auth=method['auth'],
                verify=False,
                timeout=15
            )
            
            print(f"   Status: {response.status_code}")
            
            if response.status_code == 200:
                print(f"   ✅ SUCCESS with {method['name']}!")
                try:
                    data = response.json()
                    print(f"   Data: {json.dumps(data, indent=2)[:200]}...")
                    return data
                except:
                    print(f"   Response: {response.text[:200]}...")
            else:
                print(f"   Response: {response.text[:200]}...")
                
        except Exception as e:
            print(f"   ❌ Error: {e}")
    
    return None

test_all_auth_methods()