import requests
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
import json

# Configuration
CPANEL_URL = "https://gra112.truehost.cloud:2083/"
CPANEL_USERNAME = "ssicng"
CPANEL_TOKEN =   "H0KZ2L5QN2ZD1QDMX7YKMGKI1C3VC8Q5"  # From cPanel API Tokens
BOT_TOKEN = "8295315767:AAHxRmkHDsGUaXxFyMl9uzS5FARhanEMoXA"
AUTHORIZED_USERS = [123456789]  # Your Telegram user ID

def authorized_only(func):
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if update.effective_user.id not in AUTHORIZED_USERS:
            await update.message.reply_text("❌ Unauthorized access!")
            return
        return await func(update, context)
    return wrapper

class cPanelManager:
    def __init__(self):
        self.base_url = f"{CPANEL_URL}/execute"
        self.auth = (CPANEL_USERNAME, CPANEL_TOKEN)
    
    def create_subdomain(self, subdomain, root_domain, directory=None):
        """Create a new subdomain"""
        try:
            url = f"{self.base_url}/SubDomain/addsubdomain"
            params = {
                'domain': subdomain,
                'rootdomain': root_domain,
                'dir': directory or f"public_html/{subdomain}.{root_domain}"
            }
            
            response = requests.get(url, params=params, auth=self.auth)
            return response.json()
            
        except Exception as e:
            return {'error': str(e)}
    
    def list_subdomains(self):
        """List all subdomains"""
        try:
            url = f"{self.base_url}/SubDomain/list_subdomains"
            response = requests.get(url, auth=self.auth)
            return response.json()
        except Exception as e:
            return {'error': str(e)}
    
    def delete_subdomain(self, subdomain, root_domain):
        """Delete a subdomain"""
        try:
            url = f"{self.base_url}/SubDomain/delsubdomain"
            params = {
                'domain': f"{subdomain}.{root_domain}"
            }
            response = requests.get(url, params=params, auth=self.auth)
            return response.json()
        except Exception as e:
            return {'error': str(e)}
        
    def test_auth(self):
        test_url = f"{self.base_url}/SubDomain/list_subdomains"
        response = requests.get(test_url, auth=self.auth, verify=False)
        
        if response.status_code == 401:
            return "❌ Authentication failed - check username/token"
        elif response.status_code == 403:
            return "❌ Access forbidden - check API permissions"
        else:
            return f"✅ Auth OK - Status: {response.status_code}"

# Initialize cPanel manager
cpanel = cPanelManager()

#@authorized_only
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    commands = """
🤖 cPanel Bot Commands:

/subdomain_create <subdomain> <rootdomain> - Create subdomain
/subdomain_list - List all subdomains
/subdomain_delete <subdomain> <rootdomain> - Delete subdomain
/domain_list - List domains
/disk_usage - Check disk usage

Example:
/subdomain_create shop mydomain.com
    """
    await update.message.reply_text(commands)

#@authorized_only
async def create_subdomain(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) != 2:
        await update.message.reply_text("❌ Usage: /subdomain_create <subdomain> <rootdomain>")
        return
    
    subdomain, root_domain = context.args
    
    await update.message.reply_text(f"🔄 Creating {subdomain}.{root_domain}...")
    
    cpanel = cPanelManager()
    result = cpanel.create_subdomain(subdomain, root_domain, "/home/ssicng")
    
    # Handle different response types
    if 'error' in result:
        error_msg = result['error']
        if 'raw_response' in result:
            error_msg += f"\n📄 Response: {result['raw_response'][:300]}..."
        await update.message.reply_text(f"❌ Error: {error_msg}")
    elif result.get('status') == 1:
        await update.message.reply_text(f"✅ Subdomain {subdomain}.{root_domain} created successfully!")
    else:
        await update.message.reply_text(f"❌ Failed: {result}")
#@authorized_only
async def list_subdomains(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🔄 Fetching subdomains...")
    
    result = cpanel.list_subdomains()
    
    if 'error' in result:
        await update.message.reply_text(f"❌ Error: {result['error']}")
        return
    
    subdomains = result.get('data', [])
    if not subdomains:
        await update.message.reply_text("📭 No subdomains found")
        return
    
    message = "📁 Your Subdomains:\n\n"
    for sub in subdomains:
        message += f"• {sub['domain']} → {sub.get('documentroot', 'N/A')}\n"
    
    await update.message.reply_text(message)

def main():
    app = Application.builder().token(BOT_TOKEN).build()
    
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("subdomain_create", create_subdomain))
    app.add_handler(CommandHandler("subdomain_list", list_subdomains))
    print("running...")
    
    app.run_polling()

if __name__ == "__main__":
    main()