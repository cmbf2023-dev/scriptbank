import os
root_path = os.getcwd()
root_path = os.path.join(root_path, "clone-app")
successes = []
errors = []
for root, dirs, files in os.walk(root_path):
    print(f"\nDirectory: {root}")
    print(f"Subdirectories: {len(dirs)}, Files: {len(files)}")
    
    for filename in files:
        file_path = os.path.join(root, filename)
        file_size = os.path.getsize(file_path)
        print(f"  📄 {filename} ({file_size} bytes)")
        replaced = root.replace(root_path + "\\", "").replace("\\", "/")
        print(f"replaced string {replaced}")