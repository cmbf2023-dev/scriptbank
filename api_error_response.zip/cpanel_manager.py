import requests
import json
import urllib3
import os
import base64
import datetime
import ftp_operation
import ftplib
import random
import string

# Disable SSL warnings for self-signed certs
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class cPanelManager:
    ftp_host = "ftp.autofix.buzz"
    
    def __init__(self, cpanel_host, username, api_token):
        """
        Initialize cPanel manager with Authorization header
        """
        if cpanel_host.startswith('https://'):
            cpanel_host = cpanel_host.replace('https://', '')
        elif cpanel_host.startswith('http://'):
            cpanel_host = cpanel_host.replace('http://', '')
        
        cpanel_host = cpanel_host.rstrip('/')
        
        # Add port if not present
        if ':' not in cpanel_host:
            cpanel_host = f"{cpanel_host}:2083"
        
        self.cpanel_host = cpanel_host
        self.username = username
        self.api_token = api_token
        
        # Base URL for uAPI calls
        self.base_url = f"https://{self.cpanel_host}/execute"
        
        # Authorization header
        self.headers = {
            'Authorization': f'cpanel {self.username}:{self.api_token}',
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Telegram-Bot-Manager/1.0'
        }

    def _make_request(self, endpoint, params=None, method='GET'):
        """
        Internal method to make API requests with proper error handling
        """
        url = f"{self.base_url}/{endpoint}"
        
        try:
            if method.upper() == 'GET':
                response = requests.get(
                    url,
                    params=params,
                    headers=self.headers,
                    verify=False,
                    timeout=100
                )
            else:
                response = requests.post(
                    url,
                    data=params,
                    headers=self.headers,
                    verify=False,
                    timeout=100
                )
            
            print(f"[DEBUG] URL: {url}")
            print(f"[DEBUG] Status: {response.status_code}")
            print(f"[DEBUG] Response: {response.text[:500]}...")
            
            try:
                data = response.json()
                return True, data
            except json.JSONDecodeError as e:
                self._save_error_response(response.text, endpoint, params)
                return False, f"JSON parse error: {str(e)} - Server returned non-JSON response"
                
        except requests.exceptions.RequestException as e:
            return False, f"Request failed: {str(e)}"

    def _save_error_response(self, response_text, endpoint, params):
        """Save error response to HTML file for debugging"""
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>cPanel API Error</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 40px; }}
                .info {{ background: #f0f0f0; padding: 15px; border-radius: 5px; margin-bottom: 20px; }}
                .response {{ background: #fff; border: 1px solid #ccc; padding: 15px; border-radius: 5px; }}
                pre {{ white-space: pre-wrap; word-wrap: break-word; }}
            </style>
        </head>
        <body>
            <h1>cPanel API Error Response</h1>
            <div class="info">
                <h2>Request Information</h2>
                <p><strong>Endpoint:</strong> {endpoint}</p>
                <p><strong>Parameters:</strong> {params}</p>
                <p><strong>Timestamp:</strong> {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            </div>
            <div class="response">
                <h2>Raw Response Content</h2>
                <pre>{response_text}</pre>
            </div>
        </body>
        </html>
        """
        
        file_path = f"cpanel_error_{endpoint.replace('/', '_')}.html"
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(html_content)
        print(f"[DEBUG] Error response saved to: {file_path}")

    def test_connection(self):
        """Test the cPanel API connection"""
        success, result = self._make_request("Domain/listdomains")
        
        if success:
            if result.get('result', {}).get('status') == 1:
                return True, "Connection successful!"
            else:
                errors = result.get('result', {}).get('errors', 'Unknown error')
                return False, f"API Error: {errors}"
        else:
            return False, result

    def add_subdomain(self, subdomain, rootdomain, directory=None):
        """
        Add a subdomain to an existing domain
        """
        data = {
            'domain': subdomain,
            'rootdomain': rootdomain,
        }
        
        if directory and directory.strip():
            data['dir'] = directory.strip()
        else:
            data['dir'] = f"/home/yhllnwiz/public_html/{subdomain}.{rootdomain}"
        
        print(f"[DEBUG] Final data being sent: {data}")
        
        success, result = self._make_request("SubDomain/addsubdomain", data, method='POST')
        print("success tested", success, result)

        if success:
            try:
                self.create_default_file(subdomain, rootdomain)
                if result.get('status') == 1:
                    return True, f"Subdomain {subdomain}.{rootdomain} created successfully!"
                else:
                    return False, result
            except Exception as e:
                print(f"⚠️  File creation error: {e}")
                if result.get('status') == 1:
                    return True, f"Subdomain {subdomain}.{rootdomain} created but file upload had issues"
                else:
                    return False, result
        else:
            return False, result
    
    def list_subdomains(self, rootdomain=None):
        """List all subdomains for a domain"""
        params = {}
        if rootdomain:
            params['domain'] = rootdomain
        
        success, result = self._make_request("SubDomain/listsubdomains", params)
        
        if success:
            if result.get('result', {}).get('status') == 1:
                subdomains = result.get('result', {}).get('data', [])
                return True, subdomains
            else:
                return False, result.get('result', {}).get('errors')
        else:
            return False, result

    def remove_subdomain(self, subdomain, rootdomain):
        """Remove a subdomain"""
        params = {
            'domain': subdomain,
            'rootdomain': rootdomain,
        }
        
        success, result = self._make_request("SubDomain/removesubdomain", params)
        
        if success:
            if result.get('result', {}).get('status') == 1:
                return True, f"Subdomain {subdomain}.{rootdomain} removed successfully!"
            else:
                return False, result.get('result', {}).get('errors')
        else:
            return False, result

    def create_ftp_account(self, username, password, directory, quota=0):
        """
        Create an FTP account
        """
        params = {
            'name': username,
            'password': password,
            'homedir': directory,
            'quota': quota,
        }
        
        success, result = self._make_request("Ftp/addftpacct", params)
        
        if success:
            if result.get('result', {}).get('status') == 1:
                return True, f"FTP account {username} created successfully!"
            else:
                return False, result.get('result', {}).get('errors')
        else:
            return False, result

    def list_ftp_accounts(self):
        """List all FTP accounts"""
        success, result = self._make_request("Ftp/listftpaccounts")
        
        if success:
            if result.get('result', {}).get('status') == 1:
                accounts = result.get('result', {}).get('data', [])
                return True, accounts
            else:
                return False, result.get('result', {}).get('errors')
        else:
            return False, result

    def delete_ftp_account(self, username):
        """Delete an FTP account"""
        params = {'name': username}
        
        success, result = self._make_request("Ftp/delftpacct", params)
        
        if success:
            if result.get('result', {}).get('status') == 1:
                return True, f"FTP account {username} deleted successfully!"
            else:
                return False, result.get('result', {}).get('errors')
        else:
            return False, result

    def change_ftp_password(self, username, new_password):
        """Change FTP account password"""
        params = {
            'name': username,
            'password': new_password,
        }
        
        success, result = self._make_request("Ftp/changeftppass", params)
        
        if success:
            if result.get('result', {}).get('status') == 1:
                return True, f"FTP password for {username} changed successfully!"
            else:
                return False, result.get('result', {}).get('errors')
        else:
            return False, result

    def create_database(self, database_name):
        """Create a MySQL database"""
        params = {'name': database_name}
        
        success, result = self._make_request("Mysql/create_database", params)
        
        if success:
            if result.get('result', {}).get('status') == 1:
                return True, f"Database {database_name} created successfully!"
            else:
                return False, result.get('result', {}).get('errors')
        else:
            return False, result

    def create_database_user(self, username, password):
        """Create a MySQL database user"""
        params = {
            'name': username,
            'password': password
        }
        
        success, result = self._make_request("Mysql/create_user", params)
        
        if success:
            if result.get('result', {}).get('status') == 1:
                return True, f"Database user {username} created successfully!"
            else:
                return False, result.get('result', {}).get('errors')
        else:
            return False, result
        
    def generate_ftp_password(self, length=12):
        """Generate a strong FTP password"""
        chars = string.ascii_letters + string.digits + "!@#$%^&*"
        return ''.join(random.choice(chars) for _ in range(length))
    
    def create_default_file(self, subdomain, rootdomain, ftp_creds=None):
        """
        Upload clone-app files to the subdomain directory via FTP
        
        Args:
            subdomain: Subdomain name
            rootdomain: Root domain name
            ftp_creds: Optional dict with 'user', 'password' keys. Uses defaults if not provided.
        """
        try:
            # Get the absolute path to clone-app
            local_dir = os.path.join(os.getcwd(), "clone-app")
            
            if not os.path.exists(local_dir):
                print(f"❌ Clone-app directory not found: {local_dir}")
                return False, f"Clone-app directory not found: {local_dir}"
            
            # FTP credentials (use provided or defaults)
            ftp_user = ftp_creds.get('user') if ftp_creds else "joel@autofix.buzz"
            ftp_pass = ftp_creds.get('password') if ftp_creds else "Magnet1230!"
            
            # Initialize FTP connection
            ftp = ftp_operation.FTPOperations(
                self.ftp_host,
                ftp_user,
                ftp_pass,
                21
            )
            
            # Connect to FTP
            if not ftp.connect():
                return False, "Failed to connect to FTP server"
            
            # Remote directory path
            remote_base_dir = f"{subdomain}.{rootdomain}"
            
            print(f"\n📤 Uploading files...")
            print(f"   Local: {local_dir}")
            print(f"   Remote: {remote_base_dir}")
            
            # Upload directory recursively
            successes, errors = ftp.upload_directory_recursive(
                local_dir=local_dir,
                remote_base_dir=remote_base_dir
            )
            
            # Disconnect
            ftp.disconnect()
            
            # Report results
            if successes:
                print(f"\n✅ Upload complete!")
                print(f"   Success: {len(successes)} files")
                print(f"   Errors: {len(errors)} files")
                if errors:
                    for err in errors:
                        print(f"   - {err['file']}: {err}")
                return True, f"Uploaded {len(successes)} files with {len(errors)} errors"
            else:
                print(f"\n❌ Upload failed - no files were uploaded")
                return False, f"Failed to upload files. Errors: {errors}"
                
        except Exception as e:
            print(f"❌ Exception during file upload: {e}")
            import traceback
            traceback.print_exc()
            return False, f"Exception: {str(e)}"
    
    def download_subdomain_as_zip(self, subdomain, rootdomain, ftp_creds=None, output_path=None):
        """
        Download entire subdomain directory as a ZIP file from FTP
        
        Args:
            subdomain: Subdomain name
            rootdomain: Root domain name
            ftp_creds: Optional dict with 'user', 'password' keys
            output_path: Where to save the ZIP file (default: current directory)
        
        Returns:
            Tuple of (success: bool, message: str, zip_path: str)
        """
        try:
            # FTP credentials
            ftp_user = ftp_creds.get('user') if ftp_creds else "joddy@autofix.buzz"
            ftp_pass = ftp_creds.get('password') if ftp_creds else "Magnet1230!"
            
            # Initialize FTP connection
            ftp = ftp_operation.FTPOperations(
                self.ftp_host,
                ftp_user,
                ftp_pass,
                21
            )
            
            # Connect to FTP
            if not ftp.connect():
                return False, "Failed to connect to FTP server", None
            
            # Remote directory path
            remote_dir = f"{subdomain}.{rootdomain}"
            
            # Output ZIP path
            if output_path is None:
                output_path = os.getcwd()
            
            zip_filename = f"{subdomain}_{rootdomain}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
            zip_filepath = os.path.join(output_path, zip_filename)
            
            print(f"\n📥 Downloading subdomain as ZIP...")
            print(f"   Remote: {remote_dir}")
            print(f"   Output: {zip_filepath}")
            
            # Download as ZIP
            success = ftp.download_directory_as_zip(remote_dir, zip_filepath)
            
            # Disconnect
            ftp.disconnect()
            
            if success:
                return True, f"✅ ZIP created successfully", zip_filepath
            else:
                return False, "Failed to create ZIP", None
                
        except Exception as e:
            print(f"❌ Exception during ZIP download: {e}")
            import traceback
            traceback.print_exc()
            return False, f"Exception: {str(e)}", None