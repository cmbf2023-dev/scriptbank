import ftplib
import os
import zipfile
import io
from datetime import datetime

class FTPOperations:
    def __init__(self, host, username, password, port=21):
        self.host = host
        self.username = username
        self.password = password
        self.port = port
        self.ftp = ftplib.FTP()
    
    def connect(self):
        """Establish FTP connection"""
        try:
            self.ftp.connect(self.host, self.port)
            self.ftp.login(self.username, self.password)
            print("✅ FTP Connected successfully")
            return True
        except Exception as e:
            print(f"❌ FTP Connection failed: {e}")
            return False
    
    def disconnect(self):
        """Close FTP connection"""
        try:
            self.ftp.quit()
            print("✅ FTP Disconnected successfully")
        except:
            self.ftp.close()
    
    def list_files(self, path='.'):
        """List files and directories in a path"""
        try:
            files = []
            self.ftp.retrlines(f'LIST {path}', files.append)
            return files
        except Exception as e:
            print(f"❌ Error listing files: {e}")
            return []
    
    def change_directory(self, path):
        """Change current directory"""
        try:
            self.ftp.cwd(path)
            print(f"✅ Changed to directory: {path}")
            return True
        except Exception as e:
            print(f"❌ Error changing directory: {e}")
            return False
    
    def create_directory(self, dir_name):
        """Create new directory - handles existing directories gracefully"""
        try:
            self.ftp.mkd(dir_name)
            print(f"✅ Created directory: {dir_name}")
            return True
        except ftplib.error_perm as e:
            # Directory might already exist, which is okay
            if "550" in str(e):  # 550 = File unavailable (could be existing dir)
                print(f"⚠️  Directory may already exist: {dir_name}")
                return True  # Return True since we don't need to create it
            else:
                print(f"❌ Error creating directory: {e}")
                return False
        except Exception as e:
            print(f"❌ Error creating directory: {e}")
            return False
    
    def remove_directory(self, dir_name):
        """Remove directory"""
        try:
            self.ftp.rmd(dir_name)
            print(f"✅ Removed directory: {dir_name}")
            return True
        except Exception as e:
            print(f"❌ Error removing directory: {e}")
            return False
    
    def upload_file(self, local_path, remote_path):
        """Upload a single file with proper path handling"""
        try:
            print(f"🔧 Uploading: {os.path.basename(local_path)}")
            print(f"   Local: {local_path}")
            print(f"   Remote: {remote_path}")
            
            # Check if local file exists
            if not os.path.exists(local_path):
                print(f"❌ Local file not found: {local_path}")
                return False
            
            # <CHANGE> Fixed: Create directory structure before upload
            remote_dir = os.path.dirname(remote_path).replace('\\', '/')
            if remote_dir and remote_dir != '.':
                # Build nested directories
                dirs = remote_dir.split('/')
                current_path = ''
                for dir_part in dirs:
                    if dir_part:
                        current_path = f"{current_path}/{dir_part}" if current_path else dir_part
                        print(f"   Creating: {current_path}")
                        self.create_directory(current_path)
            
            # Upload the file
            print(f"   Uploading...")
            with open(local_path, 'rb') as file:
                self.ftp.storbinary(f'STOR {remote_path}', file)
            
            print(f"✅ Successfully uploaded: {os.path.basename(local_path)}")
            return True
            
        except Exception as e:
            print(f"❌ Error uploading {local_path}: {e}")
            import traceback
            traceback.print_exc()
            return False

    def download_file(self, remote_path, local_path=None):
        """Download file from FTP server"""
        try:
            if local_path is None:
                local_path = os.path.basename(remote_path)
            
            with open(local_path, 'wb') as file:
                self.ftp.retrbinary(f'RETR {remote_path}', file.write)
            
            print(f"✅ Downloaded: {remote_path} → {local_path}")
            return True
        except Exception as e:
            print(f"❌ Error downloading file: {e}")
            return False
    
    def delete_file(self, remote_path):
        """Delete file from FTP server"""
        try:
            self.ftp.delete(remote_path)
            print(f"✅ Deleted file: {remote_path}")
            return True
        except Exception as e:
            print(f"❌ Error deleting file: {e}")
            return False
    
    def rename_file(self, old_name, new_name):
        """Rename file on FTP server"""
        try:
            self.ftp.rename(old_name, new_name)
            print(f"✅ Renamed: {old_name} → {new_name}")
            return True
        except Exception as e:
            print(f"❌ Error renaming file: {e}")
            return False
    
    def get_current_directory(self):
        """Get current working directory"""
        try:
            return self.ftp.pwd()
        except Exception as e:
            print(f"❌ Error getting current directory: {e}")
            return None
    
    def file_exists(self, remote_path):
        """Check if file exists on FTP server"""
        try:
            files = self.ftp.nlst(os.path.dirname(remote_path))
            return os.path.basename(remote_path) in files
        except:
            return False
        
    def upload_directory_recursive(self, local_dir, remote_base_dir):
        """Upload entire directory recursively using FTP"""
        successes = []
        errors = []
        
        print(f"\n📦 Starting directory upload...")
        print(f"   Local directory: {local_dir}")
        print(f"   Remote directory: {remote_base_dir}")
        
        for root, dirs, files in os.walk(local_dir):
            # Calculate relative path
            rel_path = os.path.relpath(root, local_dir)
            if rel_path == '.':
                remote_dir = remote_base_dir
            else:
                # <CHANGE> Fixed: Properly normalize paths for FTP
                remote_dir = f"{remote_base_dir}/{rel_path}".replace('\\', '/')
            
            print(f"\n📁 Processing: {remote_dir}")
            
            # Upload files in current directory
            for filename in files:
                local_file_path = os.path.join(root, filename)
                remote_file_path = f"{remote_dir}/{filename}".replace('\\', '/')
                
                print(f"   File: {filename}")
                if self.upload_file(local_file_path, remote_file_path):
                    successes.append(remote_file_path)
                else:
                    errors.append({
                        'file': filename,
                        'local': local_file_path,
                        'remote': remote_file_path
                    })
        
        return successes, errors
    
    def get_file_size(self, remote_path):
        """Get file size"""
        try:
            self.ftp.sendcmd('TYPE I')  # Binary mode
            size = self.ftp.size(remote_path)
            self.ftp.sendcmd('TYPE A')  # Back to ASCII mode
            return size
        except:
            return None
    
    def get_file_mod_time(self, remote_path):
        """Get file modification time"""
        try:
            response = self.ftp.voidcmd(f"MDTM {remote_path}")
            return response[4:]  # Returns timestamp
        except:
            return None
    
    # <CHANGE> NEW: Add zip functionality
    def download_directory_as_zip(self, remote_dir, local_zip_path):
        """
        Download entire remote directory as a ZIP file
        
        Args:
            remote_dir: Remote directory path to zip
            local_zip_path: Local path where to save the zip file
        """
        try:
            print(f"\n📦 Creating ZIP archive...")
            print(f"   Remote source: {remote_dir}")
            print(f"   Local destination: {local_zip_path}")
            
            zip_buffer = io.BytesIO()
            
            with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
                self._zip_remote_directory(remote_dir, '', zf)
            
            # Write to file
            with open(local_zip_path, 'wb') as f:
                f.write(zip_buffer.getvalue())
            
            file_size = os.path.getsize(local_zip_path)
            print(f"✅ ZIP created successfully: {local_zip_path}")
            print(f"   Size: {file_size / (1024*1024):.2f} MB")
            return True
            
        except Exception as e:
            print(f"❌ Error creating ZIP: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _zip_remote_directory(self, remote_path, arc_prefix, zip_file):
        """Recursively add remote directory contents to zip"""
        try:
            items = self.ftp.nlst(remote_path)
            
            for item in items:
                if item in ['.', '..']:
                    continue
                
                full_remote_path = f"{remote_path}/{item}".replace('\\', '/')
                arc_path = f"{arc_prefix}/{item}".replace('\\', '/').lstrip('/')
                
                try:
                    # Try to change to this path (if it's a directory)
                    self.ftp.cwd(full_remote_path)
                    self.ftp.cwd('..')
                    
                    # It's a directory - recurse
                    print(f"   📁 Including directory: {arc_path}/")
                    self._zip_remote_directory(full_remote_path, arc_path, zip_file)
                    
                except ftplib.error_perm:
                    # It's a file - download and add to zip
                    print(f"   📄 Including file: {arc_path}")
                    try:
                        file_buffer = io.BytesIO()
                        self.ftp.retrbinary(f'RETR {full_remote_path}', file_buffer.write)
                        file_buffer.seek(0)
                        zip_file.writestr(arc_path, file_buffer.getvalue())
                    except Exception as e:
                        print(f"   ⚠️  Skipped: {arc_path} ({e})")
                        
        except Exception as e:
            print(f"   ⚠️  Error processing {remote_path}: {e}")