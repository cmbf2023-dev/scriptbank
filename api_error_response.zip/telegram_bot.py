import os
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
from cpanel_manager import cPanelManager

# For local testing, you can set these or hardcode them
CPANEL_URL = os.getenv("CPANEL_URL", "https://lim110.truehost.cloud:2083/")
CPANEL_USERNAME = os.getenv("CPANEL_USERNAME", "yhllnwiz")
CPANEL_TOKEN = os.getenv("CPANEL_TOKEN", "JD6W5UAPDFQF6GX44ZD6814LJANA3U7M")
BOT_TOKEN = os.getenv("BOT_TOKEN", "8295315767:AAHxRmkHDsGUaXxFyMl9uzS5FARhanEMoXA")
AUTHORIZED_USERS = [123456789]  # Your Telegram user ID

# Initialize cPanel manager
cpanel = cPanelManager(CPANEL_URL, CPANEL_USERNAME, CPANEL_TOKEN)

def authorized_only(func):
    """Decorator to check if user is authorized"""
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if update.effective_user.id not in AUTHORIZED_USERS:
            await update.message.reply_text("❌ Unauthorized access!")
            return
        return await func(update, context)
    return wrapper

# ==================== SUBDOMAIN COMMANDS ====================

#@authorized_only
async def create_subdomain_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Create subdomain: /subdomain_create <subdomain> <rootdomain> [directory]"""
    if len(context.args) < 2:
        await update.message.reply_text(
            "❌ Usage: /subdomain_create <subdomain> <rootdomain> [directory]\n"
            "Example: /subdomain_create shop example.com"
        )
        return
    
    subdomain = context.args[0]
    root_domain = context.args[1]
    directory = context.args[2] if len(context.args) > 2 else None
    
    await update.message.reply_text(f"🔄 Creating {subdomain}.{root_domain}...")
    
    data, result = cpanel.add_subdomain(subdomain, root_domain, directory)
    
    if data:
        await update.message.reply_text(f"✅ Subdomain {subdomain}.{root_domain} created successfully!")
    else:
        error = result
        await update.message.reply_text(f"❌ Failed to create subdomain:\n{error}")

#@authorized_only
async def list_subdomains_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List all subdomains"""
    await update.message.reply_text("🔄 Fetching subdomains...")
    
    result = cpanel.list_subdomains()
    
    if 'error' in result:
        await update.message.reply_text(f"❌ Error: {result['error']}")
        return
    
    subdomains = result.get('data', [])
    if not subdomains:
        await update.message.reply_text("📭 No subdomains found")
        return
    
    message = "📁 Your Subdomains:\n\n"
    for sub in subdomains:
        message += f"• {sub['domain']} → {sub.get('documentroot', 'N/A')}\n"
    
    await update.message.reply_text(message)

#@authorized_only
async def delete_subdomain_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Delete subdomain: /subdomain_delete <subdomain> <rootdomain>"""
    if len(context.args) != 2:
        await update.message.reply_text(
            "❌ Usage: /subdomain_delete <subdomain> <rootdomain>\n"
            "Example: /subdomain_delete shop example.com"
        )
        return
    
    subdomain = context.args[0]
    root_domain = context.args[1]
    
    await update.message.reply_text(f"🔄 Deleting {subdomain}.{root_domain}...")
    
    result = cpanel.remove_subdomain(subdomain, root_domain)
    
    if result.get('result', {}).get('status') == 1:
        await update.message.reply_text(f"✅ Subdomain {subdomain}.{root_domain} deleted successfully!")
    else:
        error = result.get('result', {}).get('errors', ['Unknown error'])[0] if result.get('result') else result.get('error', 'Unknown error')
        await update.message.reply_text(f"❌ Failed to delete subdomain:\n{error}")

# ==================== FTP COMMANDS ====================

#@authorized_only
async def create_ftp_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Create FTP account: /ftp_create <username> <password> [directory]"""
    if len(context.args) < 2:
        await update.message.reply_text(
            "❌ Usage: /ftp_create <username> <password> [directory]\n"
            "Example: /ftp_create ftpuser securepass123"
        )
        return
    
    username = context.args[0]
    password = context.args[1]
    directory = context.args[2] if len(context.args) > 2 else None
    
    await update.message.reply_text(f"🔄 Creating FTP account {username}...")
    
    result = cpanel.create_ftp_account(username, password, directory)
    
    if result.get('result', {}).get('status') == 1:
        await update.message.reply_text(f"✅ FTP account {username} created successfully!")
    else:
        error = result.get('result', {}).get('errors', ['Unknown error'])[0] if result.get('result') else result.get('error', 'Unknown error')
        await update.message.reply_text(f"❌ Failed to create FTP account:\n{error}")

#@authorized_only
async def list_ftp_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List all FTP accounts"""
    await update.message.reply_text("🔄 Fetching FTP accounts...")
    
    result = cpanel.list_ftp_accounts()
    
    if 'error' in result:
        await update.message.reply_text(f"❌ Error: {result['error']}")
        return
    
    accounts = result.get('data', [])
    if not accounts:
        await update.message.reply_text("📭 No FTP accounts found")
        return
    
    message = "📂 Your FTP Accounts:\n\n"
    for account in accounts:
        message += f"• {account['user']} ({account['homedir']})\n"
    
    await update.message.reply_text(message)

#@authorized_only
async def delete_ftp_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Delete FTP account: /ftp_delete <username>"""
    if len(context.args) != 1:
        await update.message.reply_text(
            "❌ Usage: /ftp_delete <username>\n"
            "Example: /ftp_delete ftpuser"
        )
        return
    
    username = context.args[0]
    
    await update.message.reply_text(f"🔄 Deleting FTP account {username}...")
    
    result = cpanel.delete_ftp_account(username)
    
    if result.get('result', {}).get('status') == 1:
        await update.message.reply_text(f"✅ FTP account {username} deleted successfully!")
    else:
        error = result.get('result', {}).get('errors', ['Unknown error'])[0] if result.get('result') else result.get('error', 'Unknown error')
        await update.message.reply_text(f"❌ Failed to delete FTP account:\n{error}")

# ==================== DOMAIN/INFO COMMANDS ====================

#@authorized_only
async def list_domains_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List all domains"""
    await update.message.reply_text("🔄 Fetching domains...")
    
    result = cpanel.list_domains()
    
    if 'error' in result:
        await update.message.reply_text(f"❌ Error: {result['error']}")
        return
    
    domains = result.get('data', [])
    if not domains:
        await update.message.reply_text("📭 No domains found")
        return
    
    message = "🌐 Your Domains:\n\n"
    for domain in domains:
        message += f"• {domain['domain']}\n"
    
    await update.message.reply_text(message)

#@authorized_only
async def disk_usage_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Get account disk usage"""
    await update.message.reply_text("🔄 Fetching disk usage...")
    
    result = cpanel.get_disk_usage()
    
    if 'error' in result:
        await update.message.reply_text(f"❌ Error: {result['error']}")
        return
    
    data = result.get('data', {})
    message = "💾 Account Summary:\n\n"
    
    for key, value in data.items():
        message += f"• {key}: {value}\n"
    
    await update.message.reply_text(message)

#@authorized_only
async def test_connection_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Test cPanel API connection"""
    await update.message.reply_text("🔄 Testing connection...")
    
    if cpanel.test_connection():
        await update.message.reply_text("✅ cPanel API connection successful!")
    else:
        await update.message.reply_text("❌ cPanel API connection failed!")

#@authorized_only
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show available commands"""
    commands = """
🤖 cPanel Manager Bot

🏢 SUBDOMAIN COMMANDS:
/subdomain_create <subdomain> <domain> - Create subdomain
/subdomain_list - List all subdomains
/subdomain_delete <subdomain> <domain> - Delete subdomain

📂 FTP COMMANDS:
/ftp_create <username> <password> [dir] - Create FTP account
/ftp_list - List FTP accounts
/ftp_delete <username> - Delete FTP account

🌐 DOMAIN COMMANDS:
/domain_list - List domains
/disk_usage - Check disk usage

🔧 UTILITY COMMANDS:
/test_connection - Test API connection

Examples:
/subdomain_create shop example.com
/ftp_create myuser password123
"""
    await update.message.reply_text(commands)

def main():
    app = Application.builder().token(BOT_TOKEN).build()
    # Add handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("subdomain_create", create_subdomain_cmd))
    app.add_handler(CommandHandler("subdomain_list", list_subdomains_cmd))
    app.add_handler(CommandHandler("subdomain_delete", delete_subdomain_cmd))
    app.add_handler(CommandHandler("ftp_create", create_ftp_cmd))
    app.add_handler(CommandHandler("ftp_list", list_ftp_cmd))
    app.add_handler(CommandHandler("ftp_delete", delete_ftp_cmd))
    app.add_handler(CommandHandler("domain_list", list_domains_cmd))
    app.add_handler(CommandHandler("disk_usage", disk_usage_cmd))
    app.add_handler(CommandHandler("test_connection", test_connection_cmd))
    
    print("✅ Bot started. Polling for messages...")
    app.run_polling()

if __name__ == "__main__":
    main()
