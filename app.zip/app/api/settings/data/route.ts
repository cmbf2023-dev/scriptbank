import { NextRequest, NextResponse } from 'next/server'
import * as queries from '@/lib/supabase/queries'
import { createClient } from '@/lib/supabase/server'

/**
 * Export user data (backup)
 */
export async function POST(request: NextRequest) {
  try {
    const userId = request.headers.get('x-user-id') || 'demo-user'
    const body = await request.json()
    const { action } = body

    console.log('[v0] Data action:', action, 'for user:', userId)

    const supabase = await createClient()

    if (action === 'export') {
      const groups = await queries.getUserGroups(userId)
      const settings = await queries.getUserSettings(userId)
      const activities = await queries.getRecentActivities(userId, 10000)

      const exportData = {
        exportedAt: new Date().toISOString(),
        userId,
        groups,
        settings,
        activities: activities?.slice(0, 1000),
        summary: {
          totalGroups: groups?.length || 0,
          totalActivities: activities?.length || 0,
        },
      }

      return NextResponse.json({
        success: true,
        data: exportData,
        downloadUrl: '/downloads/telegram-clone-export-' + Date.now() + '.json',
        size: JSON.stringify(exportData).length + ' bytes',
      })
    }

    if (action === 'clear-cache') {
      // In production, implement cache clearing logic
      console.log('[v0] Cache cleared for user:', userId)
      return NextResponse.json({
        success: true,
        message: 'Cache cleared successfully',
      })
    }

    if (action === 'delete-all') {
      // Mark user and associated data as inactive
      await queries.updateUserSettings(userId, {
        settings_json: { isDeleted: true },
      })
      
      console.log('[v0] All data marked for deletion for user:', userId)
      return NextResponse.json({
        success: true,
        message: 'All data has been marked for deletion',
      })
    }

    return NextResponse.json(
      { error: 'Invalid action' },
      { status: 400 }
    )
  } catch (error) {
    console.error('[v0] Data action error:', error)
    return NextResponse.json(
      { error: 'Failed to process data action', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
