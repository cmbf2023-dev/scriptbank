import { NextRequest, NextResponse } from 'next/server'
import { getSyncManager } from '@/lib/sync-manager'
import * as queries from '@/lib/supabase/queries'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { groupId } = body

    if (!groupId) {
      return NextResponse.json(
        { error: 'Group ID is required' },
        { status: 400 }
      )
    }
    
    const group = await queries.getGroup(groupId)
    if (!group) {
      return NextResponse.json(
        { error: 'Group not found' },
        { status: 404 }
      )
    }

    const syncManager = getSyncManager(true)
    
    // Start live sync for this group
    await syncManager.startLiveSync(
      /*groupId: group.id,*/
      `mirror-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      group.sourceGroupId,
      group.destinationGroupId,
      /*userId: group.userId,*/
       true, // or make this configurable
      true,
      true,
      true,
      60 * 5
    )

    // Update group status in database
    await queries.updateGroupStatus(groupId, 'live_syncing')

    return NextResponse.json({
      success: true,
      groupId,
      status: 'live_sync_started',
      message: 'Live synchronization started'
    })

  } catch (error) {
    console.error('[Live Sync] Error:', error)
    return NextResponse.json(
      {
        error: 'Failed to start live sync',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}