import { NextRequest, NextResponse } from 'next/server'
import * as queries from '@/lib/supabase/queries'

/**
 * Get current sync progress for all active groups
 */
export async function GET(request: NextRequest) {
  try {
    const jobId = request.nextUrl.searchParams.get('jobId')
    
    if (jobId) {
      const job = await queries.getCloneJobProgress(jobId)
      
      return NextResponse.json({
        success: true,
        progress: {
          jobId: job.id,
          groupId: job.group_id,
          totalMessages: job.total_items,
          syncedMessages: job.processed_items,
          failedMessages: job.status === 'failed' ? (job.total_items - job.processed_items) : 0,
          status: job.status,
          progress: job.progress_percent,
          error: job.error_message,
          startedAt: job.started_at,
          completedAt: job.completed_at,
        }
      })
    }

    const userId = request.headers.get('x-user-id') || 'demo-user'
    const groups = await queries.getUserGroups(userId)
    
    const progress = groups
      .filter((group: any) => group.status !== 'completed')
      .map((group: any) => ({
        groupId: group.id,
        sourceGroupId: group.source_group_id,
        destinationGroupId: group.destination_group_id,
        status: group.status,
        totalMessages: group.total_members,
        syncedMessages: group.cloned_members,
        failedMessages: 0,
        progress: group.status === 'completed' ? 100 : 50,
      }))

    return NextResponse.json({ success: true, progress })
  } catch (error) {
    console.error('[v0] Sync progress fetch error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch sync progress', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
