import { NextRequest, NextResponse } from 'next/server'
import { getSyncManager } from '@/lib/sync-manager'
import { getTelegramService } from '@/lib/telegram-service'
import { createClient } from '@/lib/supabase/server'
import * as queries from '@/lib/supabase/queries'

/**
 * Live Mirroring Endpoint
 * Sets up real-time webhook-based message synchronization
 * Messages from source group are immediately copied to destination
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { sourceGroupId, destGroupId, preserveSenders, silentAdd, userId } = body

    if (!sourceGroupId || !destGroupId) {
      return NextResponse.json(
        { error: 'Source and destination group IDs are required' },
        { status: 400 }
      )
    }

    console.log('[v0] Live mirroring initiated:', {
      source: sourceGroupId,
      dest: destGroupId,
    })

    const telegramService = getTelegramService()
    const syncManager = getSyncManager()

    /*try {
      await telegramService.getChat(sourceGroupId)
      await telegramService.getChat(destGroupId)
    } catch (error) {
      console.error('[v0] Group validation failed:', error)
      return NextResponse.json(
        { error: 'Unable to access one or both groups' },
        { status: 400 }
      )
    }*/

    const supabase = await createClient()
    
    /*const group = await queries.createGroup(userId, {
      sourceGroupId,
      destinationGroupId: destGroupId,
      sourceGroupName: body.sourceGroupName,
      destinationGroupName: body.destGroupName,
      cloneMethod: 'live',
    })

    const job = await queries.createCloneJob(group.id, 'live', 0)
    
    await queries.updateGroupStatus(group.id, 'active')*/

    const jobId = `mirror-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`

    const syncJob = {
      jobId,
      sourceGroupId,
      destGroupId,
      method: 'live' as const,
      preserveSenders: preserveSenders ?? true,
      silentAdd: silentAdd ?? true,
      userId: userId ?? 0,
      createdAt: new Date(),
    }
    console.log("easy entery")
    await syncManager.startLiveSync(syncJob.jobId, syncJob.sourceGroupId,syncJob.destGroupId, true, true, false, true, 60 * 5 )//monitor for 5 minutes

    const webhookUrl = `${process.env.NEXT_PUBLIC_APP_URL}/api/webhooks/telegram`

    console.log('[v0] Live mirroring initiated:', {
      source: sourceGroupId,
      dest: destGroupId,
    })

    return NextResponse.json({
      success: true,
      status: 'active',
      method: 'live',
      sourceGroupId,
      destGroupId,
      webhookUrl,
      createdAt: new Date().toISOString(),
    })
  } catch (error) {
    console.error('[v0] Live mirror error:', error)
    return NextResponse.json(
      {
        error: 'Failed to initiate live mirroring',
        details: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    )
  }
}
