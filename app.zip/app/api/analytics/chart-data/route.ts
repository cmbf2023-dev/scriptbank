import { NextRequest, NextResponse } from 'next/server'
import * as queries from '@/lib/supabase/queries'

/**
 * Get chart data for analytics visualizations
 */
export async function GET(request: NextRequest) {
  try {
    const metric = request.nextUrl.searchParams.get('metric') || 'messages'
    const timeRange = request.nextUrl.searchParams.get('range') || '24h'
    const userId = request.headers.get('x-user-id') || 'demo-user'

    console.log('[v0] Fetching chart data:', { metric, timeRange, userId })

    const activities = await queries.getRecentActivities(userId, 1000)
    
    const now = new Date()
    let startTime = new Date(now)
    let intervals = 24
    let intervalMs = 60 * 60 * 1000 // 1 hour
    
    if (timeRange === '24h') {
      startTime.setHours(startTime.getHours() - 24)
      intervals = 24
      intervalMs = 60 * 60 * 1000
    } else if (timeRange === '7d') {
      startTime.setDate(startTime.getDate() - 7)
      intervals = 7
      intervalMs = 24 * 60 * 60 * 1000
    } else if (timeRange === '30d') {
      startTime.setDate(startTime.getDate() - 30)
      intervals = 30
      intervalMs = 24 * 60 * 60 * 1000
    }

    const chartData = []
    for (let i = 0; i < intervals; i++) {
      const intervalStart = new Date(startTime.getTime() + i * intervalMs)
      const intervalEnd = new Date(intervalStart.getTime() + intervalMs)
      
      const intervalActivities = (activities || []).filter((a: any) => {
        const actTime = new Date(a.created_at)
        return actTime >= intervalStart && actTime < intervalEnd
      })

      const messages = intervalActivities.filter((a: any) => a.operation === 'message_synced').length
      const members = intervalActivities.filter((a: any) => a.operation === 'member_added').length
      const avgSyncTime = intervalActivities.length > 0 
        ? intervalActivities.reduce((sum: number, a: any) => sum + (a.details?.duration_ms || 300), 0) / intervalActivities.length
        : 300

      const timeStr = timeRange === '24h' 
        ? `${intervalStart.getHours().toString().padStart(2, '0')}:00`
        : intervalStart.toLocaleDateString()

      chartData.push({
        time: timeStr,
        messages,
        members,
        avgSyncTime: Math.round(avgSyncTime),
      })
    }

    return NextResponse.json({ success: true, data: chartData })
  } catch (error) {
    console.error('[v0] Chart data error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch chart data', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
