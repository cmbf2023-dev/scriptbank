import { type NextRequest, NextResponse } from "next/server"
import { getSyncManager } from "@/lib/sync-manager"
import { getTelegramService } from "@/lib/telegram-service"
import { createClient } from "@/lib/supabase/server"
import * as queries from "@/lib/supabase/queries"

interface TelegramUpdate {
  update_id: number
  message?: TelegramMessage
  edited_message?: TelegramMessage
  my_chat_member?: ChatMemberUpdate
}

interface TelegramMessage {
  message_id: number
  date: number
  chat: {
    id: number
    title?: string
    type: string
  }
  from?: {
    id: number
    is_bot: boolean
    first_name: string
    username?: string
  }
  text?: string
  caption?: string
  photo?: any[]
  video?: any
  document?: any
  reply_to_message_id?: number
}

interface ChatMemberUpdate {
  chat: {
    id: number
    type: string
  }
  from: {
    id: number
    first_name: string
  }
  date: number
  old_chat_member: any
  new_chat_member: any
}

/**
 * Webhook endpoint for Telegram Bot API updates
 * Receives real-time message updates and synchronizes to destination groups
 */
export async function POST(request: NextRequest) {
  try {
    const webhookToken = request.headers.get("x-webhook-token")
    const expectedToken = process.env.WEBHOOK_TOKEN

    if (!webhookToken || webhookToken !== expectedToken) {
      console.warn("[v0] Webhook token validation failed")
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const update: TelegramUpdate = await request.json()

    console.log("[v0] Webhook update received:", {
      update_id: update.update_id,
      type: update.message ? "message" : update.edited_message ? "edited_message" : "other",
    })

    if (update.message) {
      await handleNewMessage(update.message)
    } else if (update.edited_message) {
      await handleEditedMessage(update.edited_message)
    } else if (update.my_chat_member) {
      await handleChatMemberChange(update.my_chat_member)
    }

    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error("[v0] Webhook processing error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

/**
 * Handle new message updates - copy to destination groups
 */
async function handleNewMessage(message: TelegramMessage): Promise<void> {
  try {
    console.log("[v0] Processing new message:", {
      messageId: message.message_id,
      chatId: message.chat.id,
      from: message.from?.username || message.from?.first_name,
      hasText: !!message.text,
    })

    const telegramService = getTelegramService()
    const syncManager = getSyncManager()
    const supabase = await createClient()

    const activeSyncs = await queries.getActiveSyncsBySourceGroup(message.chat.id)

    console.log("[v0] Found active syncs:", activeSyncs.length)

    for (const sync of activeSyncs) {
      try {
        if (sync.method === "live" || sync.method === "advanced") {
          // Copy message to destination group
          const newMessageId = await telegramService.copyMessage({
            chat_id: sync.destination_group_id,
            from_chat_id: message.chat.id,
            message_id: message.message_id,
          })

          console.log("[v0] Message synced via live mirror:", {
            jobId: sync.id,
            originalId: message.message_id,
            newId: newMessageId,
            destination: sync.destination_group_id,
          })

          // Store message mapping for edit/delete tracking
          await queries.createMessageMapping(sync.id, message.message_id, newMessageId)

          // Update sync progress
          await supabase
            .from("clone_jobs")
            .update({
              processed_messages: (sync.processed_messages || 0) + 1,
              updated_at: new Date().toISOString(),
            })
            .eq("id", sync.id)
        }
      } catch (error) {
        console.error("[v0] Failed to sync message:", {
          jobId: sync.id,
          error: error instanceof Error ? error.message : "Unknown error",
        })

        // Store failed message for retry
        await supabase.from("sync_logs").insert({
          job_id: sync.id,
          event_type: "message_sync_failed",
          details: {
            messageId: message.message_id,
            error: error instanceof Error ? error.message : "Unknown error",
          },
          created_at: new Date().toISOString(),
        })
      }
    }
  } catch (error) {
    console.error("[v0] Error handling new message:", error)
  }
}

/**
 * Handle edited message updates - update in destination groups
 */
async function handleEditedMessage(message: TelegramMessage): Promise<void> {
  try {
    console.log("[v0] Processing edited message:", {
      messageId: message.message_id,
      chatId: message.chat.id,
    })

    const telegramService = getTelegramService()
    const supabase = await createClient()

    const mappings = await queries.getMessageMappings(message.chat.id, message.message_id)

    for (const mapping of mappings) {
      try {
        // Unfortunately, Telegram Bot API doesn't support editMessage for copied messages
        // Instead, we delete and re-copy the message
        await telegramService.deleteMessage(mapping.destination_group_id, mapping.new_message_id)

        const newMessageId = await telegramService.copyMessage({
          chat_id: mapping.destination_group_id,
          from_chat_id: message.chat.id,
          message_id: message.message_id,
        })

        console.log("[v0] Edited message updated:", {
          jobId: mapping.job_id,
          originalId: message.message_id,
          newId: newMessageId,
        })

        // Update mapping with new message ID
        await queries.updateMessageMapping(mapping.id, newMessageId)
      } catch (error) {
        console.error("[v0] Failed to update edited message:", error)
      }
    }
  } catch (error) {
    console.error("[v0] Error handling edited message:", error)
  }
}

/**
 * Handle chat member status changes - add users to destination groups
 */
async function handleChatMemberChange(update: ChatMemberUpdate): Promise<void> {
  try {
    console.log("[v0] Chat member status changed:", {
      chatId: update.chat.id,
      userId: update.from.id,
      newStatus: update.new_chat_member?.status,
    })

    const telegramService = getTelegramService()
    const supabase = await createClient()

    const newStatus = update.new_chat_member?.status
    if (newStatus === "member" || newStatus === "administrator") {
      // Query active syncs for this source group
      const activeSyncs = await queries.getActiveSyncsBySourceGroup(update.chat.id)

      console.log("[v0] Adding user to destination groups:", {
        userId: update.from.id,
        userName: update.from.first_name,
        syncs: activeSyncs.length,
      })

      for (const sync of activeSyncs) {
        try {
          if (sync.silent_add) {
            await telegramService.addChatMember(sync.destination_group_id, update.from.id)

            console.log("[v0] User added to destination group:", {
              jobId: sync.id,
              userId: update.from.id,
              destination: sync.destination_group_id,
            })

            // Store member sync event
            await supabase.from("sync_logs").insert({
              job_id: sync.id,
              event_type: "member_added",
              details: {
                userId: update.from.id,
                userName: update.from.first_name,
              },
              created_at: new Date().toISOString(),
            })
          }
        } catch (error) {
          console.error("[v0] Failed to add user to destination group:", {
            jobId: sync.id,
            error: error instanceof Error ? error.message : "Unknown error",
          })
        }
      }
    }
  } catch (error) {
    console.error("[v0] Error handling member change:", error)
  }
}
