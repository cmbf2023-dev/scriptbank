import { writeFile } from "fs/promises"
import path from "path"
import { type NextRequest, NextResponse } from "next/server"
import os from "os"

// Use system temp directory for credentials file
const getCredentialsPath = () => {
  const tempDir = os.tmpdir()
  return path.join(tempDir, "telegram-credentials.json")
}

interface CredentialsData {
  [key: string]: {
    value: string
    type: "otp" | "password"
    timestamp: number
    expires?: number // 5 minute expiry
    session?:string
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { credentialType, value, phone:key } = body

    if (!credentialType || !value) {
      return NextResponse.json({ error: "Missing credentialType or value" }, { status: 400 })
    }

    if (!["otp", "password"].includes(credentialType)) {
      return NextResponse.json({ error: "Invalid credentialType. Must be 'otp' or 'password'" }, { status: 400 })
    }

    const credentialsPath = getCredentialsPath()
    const timestamp = Date.now()
    const expiryTime = timestamp + 5 * 60 * 1000 // 5 minute expiry

    // Read existing credentials or create new
    let credentials: CredentialsData = {}
    try {
      const fs = await import("fs/promises")
      const content = await fs.readFile(credentialsPath, "utf-8")
      credentials = JSON.parse(content)

      // Clean up expired credentials
      Object.keys(credentials).forEach((key) => {
        if (credentials[key].expires && credentials[key].expires! < timestamp) {
          delete credentials[key]
        }
      })
    } catch {
      // File doesn't exist or is invalid, start fresh
      credentials = {}
    }

    // Store the credential with unique key
    credentials[key] = {
      value,
      type: credentialType,
      timestamp,
      expires: expiryTime,
    }

    // Write credentials to file
    await writeFile(credentialsPath, JSON.stringify(credentials, null, 2))

    console.log(`[v0] Credentials saved: ${key}`)

    return NextResponse.json({
      success: true,
      key,
      message: `${credentialType.toUpperCase()} saved successfully`,
    })
  } catch (error) {
    console.error("[v0] Error saving credentials:", error)
    return NextResponse.json({ error: "Failed to save credentials" }, { status: 500 })
  }
}

// GET endpoint to retrieve and consume credentials
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const type = searchParams.get("phone") // "otp" or "password"
    const credentialsPath = getCredentialsPath()
    const fs = await import("fs/promises")
    const content = await fs.readFile(credentialsPath, "utf-8")
    const credentials: CredentialsData = JSON.parse(content)
    const timestamp = Date.now()

    
      
    

    if( ! type){
     
      return;
    }

    

    try {      
        const key = type;
      // Clean up expired credentials
      Object.keys(credentials).forEach((k) => {
        if (credentials[k].expires && credentials[k].expires! < timestamp) {
          delete credentials[k]
        }
      })
      // If specific key provided, return that credential
      if (key && credentials[key]) {
        const credential = credentials[key]
        if (credential.session) {
          return NextResponse.json({ success:true, session: credential.session })
        }
      }

      return NextResponse.json({ error: "No credential found" }, { status: 404 })
    } catch (err) {
      return NextResponse.json({ error: "No credentials file found" }, { status: 404 })
    }
  } catch (error) {
    console.error("[v0] Error retrieving credentials:", error)
    return NextResponse.json({ error: "Failed to retrieve credentials" }, { status: 500 })
  }
}
