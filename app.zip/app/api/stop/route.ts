import { writeFile } from "fs/promises"
import path from "path"
import { type NextRequest, NextResponse } from "next/server"
import os from "os"

// Use system temp directory for credentials file
const getCredentialsPath = () => {
  const tempDir = os.tmpdir()
  return path.join(tempDir, "stop-job.json")
}

interface CredentialsData {
  [key: string]: {
    sourceGroupId: string
    destGroupId: string
    timestamp: number
    expires?: number // 5 minute expiry
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { sourceGroupId, destGroupId } = body

    if (!sourceGroupId || !destGroupId) {
      return NextResponse.json({ error: "Missing Source and Destination Group IDs" }, { status: 400 })
    }


    const credentialsPath = getCredentialsPath()
    const timestamp = Date.now()
    const expiryTime = timestamp + 5 * 60 * 1000 // 5 minute expiry

    // Read existing credentials or create new
    let credentials: CredentialsData = {}
    try {
      const fs = await import("fs/promises")
      const content = await fs.readFile(credentialsPath, "utf-8")
      credentials = JSON.parse(content)

      // Clean up expired credentials
      Object.keys(credentials).forEach((key) => {
        if (credentials[key].expires && credentials[key].expires! < timestamp) {
          delete credentials[key]
        }
      })
    } catch {
      // File doesn't exist or is invalid, start fresh
      credentials = {}
    }

    // Store the credential with unique key
    const key = `${sourceGroupId}-${destGroupId}`
    credentials[key] = {
      destGroupId,
      sourceGroupId,
      timestamp,
      expires: expiryTime,
    }

    // Write credentials to file
    await writeFile(credentialsPath, JSON.stringify(credentials, null, 2))

    console.log(`[v0] Credentials saved: ${key}`)

    return NextResponse.json({
      success: true,
      key,
      message: `${destGroupId.toUpperCase()} stopped successfully`,
      groupId: destGroupId
    })
  } catch (error) {
    console.error("[v0] Error saving credentials:", error)
    return NextResponse.json({ error: "Failed to save credentials" }, { status: 500 })
  }
}

// GET endpoint to retrieve and consume credentials
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const key = searchParams.get("key") // "otp" or "password"
    const groupId = searchParams.get("groupId")

    const credentialsPath = getCredentialsPath()

    try {
      const fs = await import("fs/promises")
      const content = await fs.readFile(credentialsPath, "utf-8")
      const credentials: CredentialsData = JSON.parse(content)
      const timestamp = Date.now()

      // Clean up expired credentials
      Object.keys(credentials).forEach((k) => {
        if (credentials[k].expires && credentials[k].expires! < timestamp) {
          delete credentials[k]
        }
      })

      // If specific key provided, return that credential
      if (key && credentials[key]) {
        const credential = credentials[key]
        if (credential.destGroupId === groupId) {
          delete credentials[key] // Consume the credential
          await writeFile(credentialsPath, JSON.stringify(credentials, null, 2))
          return NextResponse.json({ success:true, key: key, groupId })
        }
      }


      return NextResponse.json({ error: "No Clone Job Found" }, { status: 404 })
    } catch (err) {
      return NextResponse.json({ error: "No Clone Job Found" }, { status: 404 })
    }
  } catch (error) {
    console.error("[v0] Error retrieving credentials:", error)
    return NextResponse.json({ error: "Failed to retrieve clone jobs" }, { status: 500 })
  }
}
