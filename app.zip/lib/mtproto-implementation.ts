
import { TelegramClient, Api } from "telegram"
import { StringSession } from "telegram/sessions"
import readline from "readline"
import type bigInt from "big-integer"
import fs from "fs"
import path from "path"
import os from "os"
import { BigIntegerConverter } from "./bigIntergerConverter"
import { createClient } from "./supabase/client"
import {addSyncLog} from './utils'
import { readFile, writeFile } from "fs/promises"
import {existsSync} from "fs"

export interface MTProtoConfig {
  apiId: string
  apiHash: string
  phoneNumber?: string
  sessionString?: string
}

export interface CopyMessageResult {
  originalMessageId: number
  newMessageId?: number
  success: boolean
  error?: string
  mediaType?: string
  timestamp: Date
}

export interface CopyMessagesResult {
  total: number
  successful: number
  failed: number
  results: CopyMessageResult[]
}

export interface MessageResult {
  userId: bigInt.BigInteger
  username?: string
  success: boolean
  error?: string
  timestamp: Date
}

export interface MassMessageResult {
  total: number
  successful: number
  failed: number
  results: MessageResult[]
}

export interface MTProtoMessage {
  id: number
  peer_id: number
  from_id: number | any
  text?: string
  media?: any
  date: number
}

export interface PromptOptions {
  required?: boolean
  hidden?: boolean
  validate?: (input: string) => boolean | string
  default?: string
}

export interface MemberAddResult {
  userId: number
  success: boolean
  error?: string
}

export interface AddMembersResult {
  total: number
  successful: number
  failed: number
  results: MemberAddResult[]
}

interface MediaInfo {
  type: "photo" | "video" | "audio" | "voice" | "document" | "video_note" | "sticker" | "animation" | "unknown"
  caption?: string
  filename?: string
  mimeType?: string
}

// ============ MAIN SERVICE CLASS ============

export class MTProtoService {
  private client: TelegramClient
  private isAuthenticated = false
  private sessionString: string
  private rl: readline.Interface
  private isConnected: boolean
  private mediaDownloadDir: string
  private phoneNumber?: string // added phone number storage
  supabase: any

  constructor(config: MTProtoConfig) {
    this.sessionString = config.sessionString || ""
    this.phoneNumber = config.phoneNumber // store phone number for later authentication
    this.isConnected = false
    this.mediaDownloadDir = path.join(os.tmpdir(), "telegram-media-sync")

    // Create temp directory if it doesn't exist
    if (!fs.existsSync(this.mediaDownloadDir)) {
      fs.mkdirSync(this.mediaDownloadDir, { recursive: true })
    }

    this.supabase = createClient()
    try{
      this.supabase.from("users").select("*").eq("telegram_id", this.phoneNumber).single().then((user: { data: { api_key: string } }) =>{
        console.log("user gotten for mproto: ", user, user.data )
          if(user.data.api_key && user.data.api_key.length > 15 ){
            this.sessionString = user.data.api_key;
            this.client = new TelegramClient(
              new StringSession(this.sessionString),
              Number.parseInt(config.apiId),
              config.apiHash,
              {
                connectionRetries: 5,
              },
            )
          }
      })
    } catch(e){
      console.error("user not found: ", e)
    } finally {
      this.client = new TelegramClient(
        new StringSession(this.sessionString),
        Number.parseInt(config.apiId),
        config.apiHash,
        {
          connectionRetries: 5,
        },
      )

      this.rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout,
      })

      console.log("[v0] MTProto Service initialized with multimedia support")
    }
    

     /*const credPath = this.getCredentialsPath()

     if( !existsSync(credPath)){
      writeFile(credPath, "{}").then(done =>{
        readFile(credPath, "utf-8").then(data => {
        let matter    = [];

      if( data ){
        matter = JSON.parse(data);
      }

      if(matter[`${this.phoneNumber}`]){
        this.sessionString = matter[`${this.phoneNumber}`];
      }

        if(! this.sessionString && this.phoneNumber ){
        fetch(`${process.env.NEXT_PUBLIC_APP_URL}/api/auth/session/?phone=${this.phoneNumber}`).then(response=>response.json()).then(result =>{
          if(result.session){         
            this.client = new TelegramClient(
              new StringSession(result.session),
              Number.parseInt(config.apiId),
              config.apiHash,
              {
                connectionRetries: 5,
              },
            )
            matter[`${this.phoneNumber}`] = result.session;
            writeFile(credPath, JSON.stringify(matter))
          }
        }).catch(error=>console.log(error))
      } else {
        this.client = new TelegramClient(
          new StringSession(this.sessionString),
          Number.parseInt(config.apiId),
          config.apiHash,
          {
            connectionRetries: 5,
          },
        )
      }
      })
      })
     }else {
      readFile(credPath, "utf-8").then(data => {
        let matter    = [];

      if( data ){
        matter = JSON.parse(data);
      }

      if(matter[`${this.phoneNumber}`]){
        this.sessionString = matter[`${this.phoneNumber}`];
      }

        if(! this.sessionString && this.phoneNumber ){
        fetch(`${process.env.NEXT_PUBLIC_APP_URL}/api/auth/session/?phone=${this.phoneNumber}`).then(response=>response.json()).then(result =>{
          if(result.session){         
            this.client = new TelegramClient(
              new StringSession(result.session),
              Number.parseInt(config.apiId),
              config.apiHash,
              {
                connectionRetries: 5,
              },
            )
            matter[`${this.phoneNumber}`] = result.session;
            writeFile(credPath, JSON.stringify(matter))
          }
        }).catch(error=>console.log(error))
      } else {
        this.client = new TelegramClient(
          new StringSession(this.sessionString),
          Number.parseInt(config.apiId),
          config.apiHash,
          {
            connectionRetries: 5,
          },
        )
      }
      })
     }
        
      

      this.client = new TelegramClient(
      new StringSession(this.sessionString),
      Number.parseInt(config.apiId),
      config.apiHash,
      {
        connectionRetries: 5,
      },
    )
      

   

    

    this.rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    })

    console.log("[v0] MTProto Service initialized with multimedia support")*/
  }

  getCredentialsPath() {
    const tempDir = os.tmpdir()
    return path.join(tempDir, "stop-job.json")
  }

  // ============ DATABASE SYNC ============
  
    async storeMessageMapping(
      syncId: string,
      sourceMessageId: number,
      destMessageId: number,
      sourceChatId: number,
      destChatId: number,
    ): Promise<void> {
    const supabase = createClient()

    await supabase.from("live_message_mappings").insert({
      sync_id: syncId,
      source_message_id: sourceMessageId,
      destination_message_id: destMessageId,
      source_chat_id: sourceChatId,
      destination_chat_id: destChatId,
      created_at: new Date().toISOString(),
    })
  }

    async getMessageMapping(syncId: string, sourceMessageId: number): Promise<any> {
    const supabase = createClient()

    const { data, error } = await supabase
      .from("live_message_mappings")
      .select("*")
      .eq("sync_id", syncId)
      .eq("source_message_id", sourceMessageId)
      .single()

    return data
  }

  async updateMessageMapping(syncId: string, sourceMessageId: number, newDestMessageId: number): Promise<void> {
    const supabase = createClient()

    await supabase
      .from("live_message_mappings")
      .update({
        destination_message_id: newDestMessageId,
        updated_at: new Date().toISOString(),
      })
      .eq("sync_id", syncId)
      .eq("source_message_id", sourceMessageId)
  }


   async addSyncLog(
    groupId: string,
    jobId: string | null,
    operation: string,
    status: string,
    details?: any,
    errorMessage?: string
  ) {
    try {
      return await addSyncLog(
        groupId,
        jobId,
        operation,
        status,
        details,
        errorMessage
      )
    } catch (error) {
      console.error('[v0] Failed to add sync log:', error)
      // Don't throw - logging should never break main operations
      return null
    }
  }

  // ============ AUTHENTICATION ============

  private validatePhoneNumber(phone: string): boolean {
    const phoneRegex = /^\+[1-9]\d{1,14}$/
    return phoneRegex.test(phone)
  }

  
    async getHistory(chatId: number, limit = 100): Promise<MTProtoMessage[]> {
      if (!this.isAuthenticated) {
        await this.authenticate()
      }
  
      try {
        console.log("[v0] Fetching message history from group:", chatId)
  
        const entity = await this.client.getEntity(chatId)
  
        const messages = await this.client.getMessages(entity, {
          limit: limit,
        })
  
        console.log(`[v0] Retrieved ${messages.length} messages from Telegram`)
  
        return messages.map((message) => ({
          id: message.id,
          peer_id: chatId,
          from_id: message.senderId || 0,
          text: message.text,
          media: message.media,
          date: message.date ? Math.floor(message.date / 1000) : Date.now(),
        }))
      } catch (error) {
        console.error("[v0] Failed to get message history:", error)
        throw error
      }
    }

  
  async isMemberOfGroup(chatId: number): Promise<boolean> {
    if (!this.isAuthenticated) {
      await this.authenticate()
    }

    try {
      await this.client.getEntity(chatId)
      return true
    } catch (error) {
      console.error("[v0] Not a member of group or access denied:", error)
      return false
    }
  }

  async authenticateWithPhoneNumber(phoneNumber: string): Promise<void> {
    try {
      if (!this.validatePhoneNumber(phoneNumber)) {
        throw new Error(
          "Invalid phone number format. Please use international format with country code (e.g., +1234567890)",
        )
      }

      console.log(`[v0] Starting Telegram authentication with phone number: ${phoneNumber}`)

      await this.client.start({
        phoneNumber: async () => phoneNumber,
        password: async () =>
          await this.prompt("Please enter your 2FA password (if you have one, otherwise press Enter): ", {
            required: false,
          }),
        phoneCode: async () =>
          await this.prompt("Please enter the code you received via SMS or Telegram: ", {
            required: true,
          }),
        onError: (err) => console.error("[v0] Authentication error:", err),
      })

      this.isAuthenticated = true
      this.sessionString = this.client.session.save() as unknown as string

      console.log("[v0] ✅ Telegram authentication successful with phone number")
      console.log("[v0] Session string saved - you can reuse this for future connections ", this.sessionString )
      this.saveSession()
    } catch (error) {
      console.error("[v0] ❌ Telegram authentication failed:", error)
      throw error
    }
  }

  async saveSession(){
     //fetch(`${process.env.NEXT_PUBLIC_APP_URL}/api/auth?session=${this.sessionString}&number=${this.phoneNumber}`) 

     if( ! this.supabase){
      console.log("supabase not yet set");
      return;
     }
    this.supabase.from("users").update({
      "api_key": this.sessionString
    }).eq("telegram_id", this.phoneNumber);
    console.log("session save in database: ", this.sessionString )
  }

  async authenticate(phoneNumber?: string): Promise<void> {
    try {
      const phone = phoneNumber || this.phoneNumber

      if (phone && this.validatePhoneNumber(phone)) {
        await this.authenticateWithPhoneNumber(phone)
        return
      }

      console.log("[v0] Starting Telegram authentication...")

      await this.client.start({
        phoneNumber: async () =>
          await this.prompt("Please enter your phone number with country code (e.g., +1234567890): ", {
            required: true,
            validate: (input) => {
              if (!this.validatePhoneNumber(input)) {
                return "Please enter a valid phone number with country code (e.g., +1234567890)"
              }
              return true
            },
          }),
        password: async () =>
          await this.prompt("Please enter your 2FA password (if you have one, otherwise press Enter): ", {
            required: false,
          }),
        phoneCode: async () =>
          await this.prompt("Please enter the code you received via SMS or Telegram: ", {
            required: true,
          }),
        onError: (err) => console.error("[v0] Authentication error:", err),
      })

      this.isAuthenticated = true
      this.sessionString = this.client.session.save() as unknown as string

      console.log("[v0] ✅ Telegram authentication successful")
      console.log("[v0] Session string:", this.sessionString)
    } catch (error) {
      console.error("[v0] Telegram authentication failed:", error)
      throw error
    }
  }

  // ============ MESSAGE FORWARDING ============

  async forwardMessages(sourceChatId: number, destChatId: number, messageIds: number[]): Promise<number[]> {
    if (!this.isAuthenticated) {
      await this.authenticate()
    }

    try {
      console.log("[v0] Forwarding messages via MTProto:", {
        sourceChatId,
        destChatId,
        messageCount: messageIds.length,
      })

      const sourceEntity = await this.client.getEntity(sourceChatId)
      const destEntity = await this.client.getEntity(destChatId)

      const batchSize = 10
      const forwardedIds: number[] = []

      for (let i = 0; i < messageIds.length; i += batchSize) {
        const batch = messageIds.slice(i, i + batchSize)

        const result: any = await this.client.forwardMessages(destEntity, {
          messages: batch,
          fromPeer: sourceEntity,
        })

        const newIds = Array.isArray(result) ? result.map((msg) => msg.id) : [result.id]

        forwardedIds.push(...newIds)

        console.log(`[v0] Forwarded batch ${i / batchSize + 1}: ${newIds.length} messages`)

        await new Promise((resolve) => setTimeout(resolve, 1000))
      }

      console.log(`[v0] Successfully forwarded ${forwardedIds.length} messages`)
      return forwardedIds
    } catch (error) {
      console.error("[v0] Failed to forward messages:", error)
      throw error
    }
  }

   /**
     * Check if user has admin rights in group
     */
    async hasAdminRights(groupId: number): Promise<boolean> {
      try {
        const groupEntity = await this.client.getEntity(groupId);
        const fullChat = await this.client.invoke(
          new Api.channels.GetFullChannel({
            channel: groupEntity,
          })
        );
  
        // Check if user is admin in the chat
        const participant = await this.client.invoke(
          new Api.channels.GetParticipant({
            channel: groupEntity,
            participant: await this.client.getEntity('me'), // Current user
          })
        );
  
        const isAdmin = participant.participant instanceof Api.ChannelParticipantAdmin ||
                       participant.participant instanceof Api.ChannelParticipantCreator;
  
        console.log(`[v0] Admin check for group ${groupId}: ${isAdmin ? 'YES' : 'NO'}`);
        return isAdmin;
  
      } catch (error) {
        console.error(`[v0] Failed to check admin rights for group ${groupId}:`, error);
        return false;
      }
    }

  private async prompt(question: string, options: PromptOptions = {}): Promise<string> {
    try {
      const credentialType = this.getCredentialTypeFromQuestion(question)
      if (credentialType) {
        const credentialValue = await this.getCredentialFromFile(credentialType)

        console.log("credential value gotten: ", credentialValue )
        
        if (credentialValue) {
          console.log(`[v0] Using saved ${credentialType}...`)
          return credentialValue
        }
        console.log("Couldn't get credential value: ", credentialValue )
      }
    } catch (error) {
      console.log("[v0] Credentials file unavailable, using interactive prompt")
    }

    // Fallback to interactive console prompt
    return new Promise((resolve) => {
      const fullQuestion = options.default ? `${question} (default: ${options.default}): ` : `${question}: `

      this.rl.question(fullQuestion, (answer) => {
        if (!answer && options.default) {
          answer = options.default
        }

        if (options.required && !answer) {
          console.log("❌ This field is required.")
          resolve(this.prompt(question, options))
          return
        }

        if (options.validate && answer) {
          const validationResult = options.validate(answer)
          if (validationResult !== true) {
            console.log(`❌ ${validationResult || "Invalid input"}`)
            resolve(this.prompt(question, options))
            return
          }
        }

        resolve(answer)
      })
    })
  }

  private getCredentialTypeFromQuestion(question: string): "otp" | "password" | null {
    const lowerQuestion = question.toLowerCase()
    if (lowerQuestion.includes("code") || lowerQuestion.includes("otp") || lowerQuestion.includes("sms")) {
      return "otp"
    }
    if (lowerQuestion.includes("password") || lowerQuestion.includes("2fa")) {
      return "password"
    }
    return null
  }

  private async getCredentialFromFile(type: "otp" | "password", num = 0): Promise<string | null> {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_APP_URL}/api/auth?type=${type}&key=${this.phoneNumber}`)
      if (response.ok) {
        const data = await response.json()
        if(data.value)
          return data.value

        return new Promise((resolve)=>{
          setTimeout(async ()=>{
            num++;
            console.log("number file getting: ", num )
            if(num <= 10 )
              resolve( await this.getCredentialFromFile(type, num) )

            resolve( null );
          }, 15000)          
        })
        
      }
      
      return new Promise((resolve)=>{
          setTimeout(async ()=>{
            num++;
            console.log("number file getting: ", num )
            if(num <= 10 )
              resolve( await this.getCredentialFromFile(type, num) )

            resolve( null );
          }, 15000)          
        })
    } catch (error) {
      console.log(`[v0] Could not read ${type} from file:`, error)
    }
    return null
  }

   // ============ GROUP MANAGEMENT ============

  async getGroupMembers(chatId: number): Promise<any[]> {
    if (!this.isAuthenticated) {
      await this.authenticate()
    }

    try {
      const entity = await this.client.getEntity(chatId)
      const participants: any[] = await this.client.getParticipants(entity)

      return participants.map((participant) => ({
        id: participant.id,
        username: participant.username,
        firstName: participant.firstName,
        lastName: participant.lastName,
        isAdmin: participant.adminRights !== undefined,
      }))
    } catch (error) {
      console.error("[v0] Failed to get group members:", error)
      throw error
    }
  }

  async getGroupInfo(chatId: number): Promise<any> {
    if (!this.isAuthenticated) {
      await this.authenticate()
    }

    try {
      const fullChat: any = await this.client.getEntity(chatId)

      return {
        id: chatId,
        title: fullChat.title,
        participants_count: fullChat.participantsCount,
      }
    } catch (error) {
      console.error("[v0] Failed to get group info:", error)
      throw error
    }
  }

   /**
       * Add multiple members to group
       */
      async addMembersToGroup(
        groupId: number,
        userIds: number[],
        options?: {
          batchSize?: number;
          delayBetweenBatches?: number;
          silent?: boolean;
        }
      ): Promise<AddMembersResult> {
        try {
          console.log(`[v0] Adding ${userIds.length} members to group ${groupId}`);
    
          const groupEntity = await this.client.getEntity(groupId);
          const results: MemberAddResult[] = [];
          const batchSize = options?.batchSize || 5;
          const delay = options?.delayBetweenBatches || 5000;
    
          // Process in batches to avoid rate limits
          for (let i = 0; i < userIds.length; i += batchSize) {
            const batch = userIds.slice(i, i + batchSize);
            
            console.log(`[v0] Processing batch ${i / batchSize + 1}: ${batch.length} users`);
    
            // Get user entities for this batch
            const userEntities = [];
            for (const userId of batch) {
              try {
                const userEntity = await this.client.getEntity(userId);
                userEntities.push(userEntity);
              } catch (error:any) {
                console.error(`[v0] Failed to get entity for user ${userId}:`, error);
                results.push({
                  userId,
                  success: false,
                  error: `Failed to get user entity: ${error.message}`
                });
              }
            }
    
            if (userEntities.length > 0) {
              try {
                // Add batch of users
                await this.client.invoke(
                  new Api.channels.InviteToChannel({
                    channel: groupEntity,
                    users: userEntities,
                  })
                );          
    
                // Mark all in batch as successful
                batch.forEach(userId => {
                  results.push({
                    userId,
                    success: true
                  });
                });
    
                console.log(`[v0] ✅ Successfully added batch ${i / batchSize + 1}`);
    
              } catch (batchError:any) {
                console.error(`[v0] ❌ Failed to add batch ${i / batchSize + 1}:`, batchError);
                
                // Mark all in batch as failed
                batch.forEach(userId => {
                  results.push({
                    userId,
                    success: false,
                    error: `Batch failed: ${batchError.message}`
                  });
                });
              }
            }
    
            // Rate limiting between batches
            if (i + batchSize < userIds.length) {
              console.log(`[v0] Waiting ${delay}ms before next batch...`);
              await new Promise(resolve => setTimeout(resolve, delay));
            }
          }
    
          const successCount = results.filter(r => r.success).length;
          console.log(`[v0] Member addition completed: ${successCount}/${userIds.length} successful`);
    
          return {
            total: userIds.length,
            successful: successCount,
            failed: userIds.length - successCount,
            results
          };
    
        } catch (error) {
          console.error('[v0] Member addition failed:', error);
          throw error;
        }
      }
  
   async sendDirectMessage(userId: number, message: string): Promise<boolean> {
    await this.connect()

    try {
      const userEntity = await this.client.getEntity(userId)

      await this.client.sendMessage(userEntity, {
        message: message,
        parseMode: "html",
      })

      return true
    } catch (error: any) {
      console.error(`[v0] Failed to send DM to ${userId}:`, error.message)
      return false
    }
  }

    // ============ MESSAGE SENDING ============

  async sendMessage(chatId: number, text: string, options?: any): Promise<number> {
    if (!this.isAuthenticated) {
      await this.authenticate()
    }

    try {
      const entity = await this.client.getEntity(chatId)
      const result = await this.client.sendMessage(entity, {
        message: text,
        ...options,
      })

      return result.id
    } catch (error) {
      console.error("[v0] Failed to send message:", error)
      throw error
    }
  }

  // ============ MESSAGE COPYING (WITH MULTIMEDIA SUPPORT) ============

  async copyMessage(
    sourceChatId: number,
    destChatId: number,
    messageId: number,
    options?: {
      removeCaption?: boolean
      newCaption?: string
      addAttribution?: boolean
    },
  ): Promise<number> {
    let downloadedMediaPath: string | null = null

    try {
      console.log(`[v0] Copying message ${messageId} from ${sourceChatId} to ${destChatId}`)

      const sourceEntity = await this.client.getEntity(sourceChatId)
      const destEntity = await this.client.getEntity(destChatId)

      // Get the original message
      const messages = await this.client.getMessages(sourceEntity, {
        ids: [messageId],
      })

      if (!messages || messages.length === 0) {
        throw new Error(`Message ${messageId} not found in source chat`)
      }

      const originalMessage = messages[0]

      // Detect media type
      const mediaInfo = await this.detectMediaType(originalMessage)

      // Prepare caption
      let caption = originalMessage.text || ""

      if (options?.newCaption) {
        caption = options.newCaption
      } else if (options?.removeCaption) {
        caption = ""
      }

      // Add attribution if requested
      if (options?.addAttribution) {
        const sender: any = await originalMessage.getSender()
        const senderName = (sender?.firstName || "") + (sender?.lastName ? ` ${sender.lastName}` : "")
        const senderUsername = sender?.username ? `@${sender.username}` : ""
        const attribution = `<b>From: ${senderName} ${senderUsername}</b>`
        caption = caption ? `${attribution}\n\n${caption}` : attribution
      }

      let newMessageId: number | null = null

      // Handle media messages
      if (originalMessage.media && mediaInfo.type !== "unknown") {
        downloadedMediaPath = await this.downloadMedia(originalMessage)

        if (downloadedMediaPath) {
          newMessageId = await this.sendMediaMessage(destEntity, downloadedMediaPath, caption, mediaInfo)
        } else {
          throw new Error(`Failed to download ${mediaInfo.type} media`)
        }
      } else {
        // Handle text-only messages
        const result = await this.client.sendMessage(destEntity, {
          message: caption,
          parseMode: "html",
        })
        newMessageId = result.id
      }

      if (!newMessageId) {
        throw new Error("Failed to get new message ID")
      }

      console.log(`[v0] ✅ Message copied successfully. New ID: ${newMessageId}`)
      return newMessageId
    } catch (error) {
      console.error(`[v0] ❌ Failed to copy message ${messageId}:`, error)
      throw error
    } finally {
      // Cleanup temporary media file
      if (downloadedMediaPath) {
        this.cleanupMediaFile(downloadedMediaPath)
      }
    }
  }

  // ============ MEDIA HANDLING ============

  private cleanupMediaFile(filePath: string): void {
    try {
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath)
        console.log(`[v0] Cleaned up temp file: ${filePath}`)
      }
    } catch (error) {
      console.error(`[v0] Failed to cleanup temp file:`, error)
    }
  }

  private async detectMediaType(message: any): Promise<MediaInfo> {
    if (!message.media) {
      return { type: "unknown" }
    }

    const media = message.media
    let mediaType: MediaInfo["type"] = "unknown"
    let filename = ""
    let mimeType = ""

    if (media.className === "MessageMediaPhoto") {
      mediaType = "photo"
      filename = `photo_${message.id}.jpg`
      mimeType = "image/jpeg"
    } else if (media.className === "MessageMediaDocument") {
      const doc = media.document

      // Detect document type by MIME type
      if (doc.mimeType?.startsWith("video/")) {
        mediaType = "video"
      } else if (doc.mimeType?.startsWith("audio/")) {
        if (media.voice) {
          mediaType = "voice"
        } else {
          mediaType = "audio"
        }
      } else if (doc.mimeType === "application/x-tgsticker") {
        mediaType = "sticker"
      } else if (doc.mimeType?.startsWith("image/")) {
        mediaType = "animation"
      } else {
        mediaType = "document"
      }

      filename =
        doc.attributes?.find((attr: any) => attr.className === "DocumentAttributeFilename")?.fileName ||
        `document_${message.id}`
      mimeType = doc.mimeType || "application/octet-stream"
    } else if (media.className === "MessageMediaGeo") {
      mediaType = "document" // Treat as document for now
    }

    return {
      type: mediaType,
      caption: message.text || message.caption || "",
      filename,
      mimeType,
    }
  }

  private async downloadMedia(message: any): Promise<string | null> {
    if (!message.media) return null

    try {
      const mediaInfo = await this.detectMediaType(message)
      const downloadPath = path.join(this.mediaDownloadDir, `${message.id}_${mediaInfo.filename}`)

      console.log(`[v0] Downloading ${mediaInfo.type} media...`)

      // Download the media file
      const result = await this.client.downloadMedia(message, {
        outputFile: downloadPath,
      })

      if (result) {
        console.log(`[v0] ✅ Media downloaded to: ${downloadPath}`)
        return downloadPath
      }

      return null
    } catch (error) {
      console.error(`[v0] ❌ Failed to download media:`, error)
      return null
    }
  }



  
  private async sendMediaMessage(
    destEntity: any,
    mediaPath: string,
    caption: string,
    mediaInfo: MediaInfo,
  ): Promise<number | null> {
    try {
      console.log(`[v0] Uploading ${mediaInfo.type} to destination...`)

      const sendParams: any = {
        file: mediaPath,
      }

      if (caption) {
        sendParams.caption = caption
        sendParams.parseMode = "html"
      }

      // Send based on media type
      let result

      switch (mediaInfo.type) {
        case "photo":
          result = await this.client.sendFile(destEntity, {
            file: mediaPath,
            caption: caption || "",
            parseMode: "html",
          })
          break

        case "video":
          result = await this.client.sendFile(destEntity, {
            file: mediaPath,
            caption: caption || "",
            parseMode: "html",
            forceDocument: false,
          })
          break

        case "audio":
          result = await this.client.sendFile(destEntity, {
            file: mediaPath,
            caption: caption || "",
            parseMode: "html",
          })
          break

        case "voice":
          result = await this.client.sendFile(destEntity, {
            file: mediaPath,
            caption: caption || "",
            parseMode: "html",
          })
          break

        case "document":
        case "sticker":
        case "animation":
        default:
          result = await this.client.sendFile(destEntity, {
            file: mediaPath,
            caption: caption || "",
            parseMode: "html",
            forceDocument: true,
          })
      }

      console.log(`[v0] ✅ ${mediaInfo.type} uploaded successfully`)
      return result?.id || null
    } catch (error) {
      console.error(`[v0] ❌ Failed to send media:`, error)
      return null
    }
  }

  
    async copyMessages(
      sourceChatId: number,
      destChatId: number,
      messageIds: number[],
      options?: {
        batchSize?: number
        delayBetweenMessages?: number
        addAttribution?: boolean
        preserveSenders?: boolean
      },
    ): Promise<CopyMessagesResult> {
      const credPath = this.getCredentialsPath();

      try {
        console.log(`[v0] Copying ${messageIds.length} messages with multimedia support`)
       
  
        const results: CopyMessageResult[] = []
        const batchSize = options?.batchSize || 5
        const delay = options?.delayBetweenMessages || 2000
        const timestamp = Date.now();

  
        for (let i = 0; i < messageIds.length; i += batchSize) {
          const batch = messageIds.slice(i, i + batchSize)

           let data = await readFile(credPath, "utf8");
            let system =  [];

            if( data ){
              try {
                system = JSON.parse(data)
              } catch (e){
                system = JSON.parse("{}");
              }
            } else {
              system = JSON.parse("{}");
          }

          
          // Clean up expired credentials
          /*Object.keys(system).forEach((key) => {
            if (system[key].expires && system[key].expires! < timestamp) {
              delete system[key]
            }
          })*/
  
          console.log(
            `[v0] Processing batch ${Math.floor(i / batchSize) + 1}/${Math.ceil(messageIds.length / batchSize)}`,
          )

          //listen for stop signals from the frontend:
          const key:string = `${sourceChatId}-${destChatId}`
          const response = system[key]

          console.log(`[v0] Credentials gotten: ${key}`, response , system)

          if(response){
            delete system[key];
            console.log("stopping code")
            await writeFile(credPath, JSON.stringify(system))
            break;
          }
  
          for (const msgId of batch) {
            try {
              
              const newMessageId = await this.copyMessage(sourceChatId, destChatId, msgId, {
                addAttribution: options?.addAttribution,
              })
  
              results.push({
                originalMessageId: msgId,
                newMessageId,
                success: true,
                timestamp: new Date(),
              })
  
              // Delay between messages
              await new Promise((resolve) => setTimeout(resolve, 1000))
            } catch (error: any) {
              console.error(`[v0] Failed to copy message ${msgId}:`, error.message)
              results.push({
                originalMessageId: msgId,
                success: false,
                error: error.message,
                timestamp: new Date(),
              })
            }
          }
           // await writeFile(credPath, JSON.stringify(system))
          // Delay between batches
          if (i + batchSize < messageIds.length) {
            console.log(`[v0] Waiting ${delay}ms before next batch...`)
            await new Promise((resolve) => setTimeout(resolve, delay))
          }
        }
  
        const successCount = results.filter((r) => r.success).length
        console.log(`[v0] Batch copy completed: ${successCount}/${messageIds.length} successful`)
      
        return {
          total: messageIds.length,
          successful: successCount,
          failed: messageIds.length - successCount,
          results,
        }
      } catch (error: any) {
        console.error("[v0] Batch copy failed:", error)
        throw error
      }
    }

  async deleteMessage(chatId: number, messageId: number): Promise<boolean> {
    await this.connect()

    try {
      const entity = await this.client.getEntity(chatId)

      await this.client.deleteMessages(entity, [messageId], {
        revoke: true,
      })

      console.log(`[v0] ✅ Message ${messageId} deleted from ${chatId}`)
      return true
    } catch (error: any) {
      console.error(`[v0] ❌ Failed to delete message ${messageId}:`, error.message)
      return false
    }
  }

      // ============ BULK OPERATIONS ============
      
  async messageAllGroupMembers(
    groupId: number,
    message: string,
    options?: {
      batchSize?: number
      delayBetweenMessages?: number
      excludeAdmins?: boolean
    },
  ): Promise<MassMessageResult> {
    await this.connect()

    try {
      console.log(`[v0] Messaging all members of group ${groupId}`)

      const members = await this.getGroupMembers(groupId)

      if (!members || members.length === 0) {
        throw new Error("No members found in group")
      }

      let membersToMessage = members
      if (options?.excludeAdmins) {
        membersToMessage = members.filter((member) => !member.isAdmin)
      }

      const results: MessageResult[] = []
      const batchSize = options?.batchSize || 2
      const delay = options?.delayBetweenMessages || 10000

      console.log(`[v0] Messaging ${membersToMessage.length} members...`)

      for (let i = 0; i < membersToMessage.length; i += batchSize) {
        const batch = membersToMessage.slice(i, i + batchSize)

        console.log(`[v0] Processing batch ${i / batchSize + 1}: ${batch.length} users`)

        for (const member of batch) {
          try {
            const success = await this.sendDirectMessage(BigIntegerConverter.toNumber(member.id), message)

            results.push({
              userId: member.id,
              username: member.username,
              success: success,
              timestamp: new Date(),
            })

            await new Promise((resolve) => setTimeout(resolve, 1000))
          } catch (error: any) {
            console.error(`[v0] Failed to message user ${member.id}:`, error.message)
            results.push({
              userId: member.id,
              username: member.username,
              success: false,
              error: error.message,
              timestamp: new Date(),
            })
          }
        }

        if (i + batchSize < membersToMessage.length) {
          console.log(`[v0] Waiting ${delay}ms before next batch...`)
          await new Promise((resolve) => setTimeout(resolve, delay))
        }
      }

      const successCount = results.filter((r) => r.success).length
      console.log(`[v0] Member messaging completed: ${successCount}/${membersToMessage.length} successful`)

      return {
        total: membersToMessage.length,
        successful: successCount,
        failed: membersToMessage.length - successCount,
        results: results,
      }
    } catch (error: any) {
      console.error("[v0] Member messaging failed:", error)
      throw error
    }
  }
      



  // ============ CONNECTION ============

  async connect(): Promise<void> {
    if (this.isConnected) return

    try {
      if (!this.isAuthenticated && !this.sessionString) {
        console.log("[v0] No existing session found. Starting authentication...")
        await this.authenticate()
      }

      await this.client.connect()
      this.isConnected = true
      console.log("[v0] Connected to Telegram")
    } catch (error) {
      console.error("[v0] Connection failed:", error)
      throw error
    }
  }
}
