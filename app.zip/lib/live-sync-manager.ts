// live-sync-manager.ts
import { TelegramClient } from 'telegram';
import { NewMessage } from 'telegram/events';
import { Api } from 'telegram';
import { MTProtoService } from './mtproto-implementation';
import { BigIntegerConverter } from './bigIntergerConverter';

export interface LiveSyncConfig {
  sourceGroupId: number;
  destGroupId: number;
  syncReactions: boolean;
  syncEdits: boolean;
  syncDeletes: boolean;
  preserveSenders: boolean;
}

export class LiveSyncManager {
  private mtproto: MTProtoService;
  private activeSyncs = new Map<string, LiveSyncConfig>();
  private isListening = false;

  constructor(mtprotoService: MTProtoService) {
    this.mtproto = mtprotoService;
  }

  /**
   * Start live synchronization between groups
   */
  async startLiveSync(
    syncId: string, 
    config: LiveSyncConfig
  ): Promise<boolean> {
    try {
      console.log(`[Live] Starting live sync: ${syncId}`, config);

      // Verify we can access both groups
      const canAccessSource = await this.mtproto.isMemberOfGroup(config.sourceGroupId);
      const canAccessDest = await this.mtproto.hasAdminRights(config.destGroupId);

      if (!canAccessSource || !canAccessDest) {
        throw new Error('Cannot access source group or no admin rights in destination');
      }

      // Store sync configuration
      this.activeSyncs.set(syncId, config);

      // Start event listeners if not already running
      if (!this.isListening) {
        await this.startEventListeners();
      }

      // Log to database
      await this.logLiveSyncStart(syncId, config);

      console.log(`[Live] ✅ Live sync started: ${syncId}`);
      return true;

    } catch (error) {
      console.error(`[Live] ❌ Failed to start live sync ${syncId}:`, error);
      return false;
    }
  }

  /**
   * Stop a specific live sync
   */
  async stopLiveSync(syncId: string): Promise<boolean> {
    try {
      this.activeSyncs.delete(syncId);
      console.log(`[Live] Stopped live sync: ${syncId}`);

      // Stop listeners if no active syncs
      if (this.activeSyncs.size === 0) {
        await this.stopEventListeners();
      }

      await this.logLiveSyncStop(syncId);
      return true;

    } catch (error) {
      console.error(`[Live] Failed to stop live sync ${syncId}:`, error);
      return false;
    }
  }

  /**
   * Start listening to Telegram events
   */
  private async startEventListeners(): Promise<void> {
    try {
      const client = this.mtproto['client']; // Access the underlying client

      // Listen for new messages
      client.addEventHandler(
        this.handleNewMessage.bind(this),
        new NewMessage({})
      );

      /*// Listen for edited messages
      client.addEventHandler(
        this.handleEditedMessage.bind(this),
        new EditedMessage({})
      );

      // Listen for deleted messages (if needed)
      client.addEventHandler(
        this.handleDeletedMessage.bind(this),
        new DeletedMessage({})
      );*/

      this.isListening = true;
      console.log('[Live] ✅ Event listeners started');

    } catch (error) {
      console.error('[Live] ❌ Failed to start event listeners:', error);
      throw error;
    }
  }

  /**
   * Stop all event listeners
   */
  private async stopEventListeners(): Promise<void> {
    // Note: TelegramClient doesn't have a direct way to remove specific handlers
    // We'll manage this through our activeSyncs map
    this.isListening = false;
    console.log('[Live] Event listeners stopped');
  }

  /**
   * Handle new messages in monitored groups
   */
  private async handleNewMessage(event: any): Promise<void> {
    try {
      const message = event.message;
      const chatId = message.chatId?.value || message.peerId?.channelId?.value;

      if (!chatId) return;

      // Check if this chat has active syncs
      const relevantSyncs = Array.from(this.activeSyncs.entries())
        .filter(([_, config]) => config.sourceGroupId === chatId);

      if (relevantSyncs.length === 0) return;

      console.log(`[Live] New message in ${chatId}:`, {
        messageId: message.id,
        text: message.text?.substring(0, 100)
      });

      // Process for each relevant sync
      for (const [syncId, config] of relevantSyncs) {
        await this.syncNewMessage(message, config, syncId);
      }

    } catch (error) {
      console.error('[Live] Error handling new message:', error);
    }
  }

  /**
   * Sync a new message to destination
   */
  private async syncNewMessage(
    message: any, 
    config: LiveSyncConfig, 
    syncId: string
  ): Promise<void> {
    try {
      

      // Copy message to destination
      const newMessageId = await this.mtproto.copyMessage(
        config.sourceGroupId,
        config.destGroupId,
        message.id
      );

      // Store mapping for future reference (edits/deletes)
      await this.storeMessageMapping(
        syncId,
        message.id,
        BigIntegerConverter.toBigInteger( newMessageId ),
        config.sourceGroupId,
        config.destGroupId
      );

      console.log(`[Live] ✅ Message synced: ${message.id} → ${newMessageId}`);

      // Log the sync operation
      await this.logMessageSync(syncId, message.id, BigIntegerConverter.toBigInteger( newMessageId ), 'created');

    } catch (error:any) {
      console.error(`[Live] ❌ Failed to sync message ${message.id}:`, error);
      await this.logMessageSync(syncId, message.id, null, 'failed', error.message);
    }
  }

  /**
   * Handle edited messages
   */
  private async handleEditedMessage(event: any): Promise<void> {
    try {
      const message = event.message;
      const chatId = message.chatId?.value || message.peerId?.channelId?.value;

      if (!chatId) return;

      const relevantSyncs = Array.from(this.activeSyncs.entries())
        .filter(([_, config]) => config.sourceGroupId === chatId);

      if (relevantSyncs.length === 0 || !message.editDate) return;

      console.log(`[Live] Message edited in ${chatId}:`, message.id);

      for (const [syncId, config] of relevantSyncs) {
        if (config.syncEdits) {
          await this.syncMessageEdit(message, config, syncId);
        }
      }

    } catch (error) {
      console.error('[Live] Error handling edited message:', error);
    }
  }

  /**
   * Sync message edits
   */
  private async syncMessageEdit(
    message: any, 
    config: LiveSyncConfig, 
    syncId: string
  ): Promise<void> {
    try {
      // Get the mapping for this message
      const mapping = await this.getMessageMapping(syncId, message.id);
      
      if (!mapping || !mapping.destinationMessageId) {
        console.log(`[Live] No mapping found for edited message ${message.id}`);
        return;
      }

      // In Telegram, we can't directly edit someone else's message
      // So we'll delete the old one and send a new one
      await this.mtproto.deleteMessage(config.destGroupId, mapping.destinationMessageId);
      
      // Copy the edited message as a new message
      const newMessageId = await this.mtproto.copyMessage(
        config.sourceGroupId,
        config.destGroupId,
        message.id
      );

      // Update the mapping
      await this.updateMessageMapping(syncId, message.id, BigIntegerConverter.toBigInteger( newMessageId));

      console.log(`[Live] ✅ Edit synced: ${message.id} → ${newMessageId}`);
      await this.logMessageSync(syncId, message.id, BigIntegerConverter.toBigInteger(  newMessageId ), 'edited');

    } catch (error) {
      console.error(`[Live] ❌ Failed to sync edit ${message.id}:`, error);
    }
  }

  /**
   * Handle deleted messages
   */
  private async handleDeletedMessage(event: any): Promise<void> {
    try {
      // Implementation for handling deleted messages
      // This is more complex as we need to track message IDs
      console.log('[Live] Delete event:', event);
      
      // You would need to implement message ID tracking
      // and then delete the corresponding message in destination

    } catch (error) {
      console.error('[Live] Error handling deleted message:', error);
    }
  }

  /**
   * Database operations for message tracking
   */
  private async storeMessageMapping(
    syncId: string,
    sourceMessageId: bigInt.BigInteger,
    destMessageId: bigInt.BigInteger,
    sourceChatId: number,
    destChatId: number
  ): Promise<void> {
    // Store in your database
    await this.mtproto.storeMessageMapping(
      syncId,
      BigIntegerConverter.toNumber(sourceMessageId),
      BigIntegerConverter.toNumber(destMessageId),
      sourceChatId,
      destChatId
    );
  }

  private async getMessageMapping(
    syncId: string, 
    sourceMessageId: bigInt.BigInteger
  ): Promise<any> {
    // Retrieve from database
    return await this.mtproto.getMessageMapping(
      syncId, 
      BigIntegerConverter.toNumber(sourceMessageId)
    );
  }

  private async updateMessageMapping(
    syncId: string,
    sourceMessageId: bigInt.BigInteger,
    newDestMessageId: bigInt.BigInteger
  ): Promise<void> {
    // Update in database
    await this.mtproto.updateMessageMapping(
      syncId,
      BigIntegerConverter.toNumber(sourceMessageId),
      BigIntegerConverter.toNumber(newDestMessageId)
    );
  }

  private async logLiveSyncStart(syncId: string, config: LiveSyncConfig): Promise<void> {
    // Log to your sync_logs table
    await this.mtproto.addSyncLog(
      syncId,
      null, // jobId
      'live_sync_start',
      'running',
      config
    );
  }

  private async logLiveSyncStop(syncId: string): Promise<void> {
    await this.mtproto.addSyncLog(
      syncId,
      null,
      'live_sync_stop', 
      'completed',
      { stoppedAt: new Date() }
    );
  }

  private async logMessageSync(
    syncId: string,
    sourceMessageId: bigInt.BigInteger,
    destMessageId: bigInt.BigInteger | null,
    operation: string,
    error?: string
  ): Promise<void> {
    await this.mtproto.addSyncLog(
      syncId,
      null,
      `message_${operation}`,
      destMessageId ? 'completed' : 'failed',
      {
        sourceMessageId: BigIntegerConverter.toNumber(sourceMessageId),
        destMessageId: destMessageId ? BigIntegerConverter.toNumber(destMessageId) : null,
        error
      }
    );
  }

  /**
   * Get active live syncs
   */
  getActiveSyncs(): Map<string, LiveSyncConfig> {
    return new Map(this.activeSyncs);
  }

  /**
   * Check if a sync is active
   */
  isSyncActive(syncId: string): boolean {
    return this.activeSyncs.has(syncId);
  }
}