import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// queries.ts - ADD THESE METHODS
import { createClient } from "./supabase/client"

/**
 * Add sync log entry for tracking operations
 */
export async function addSyncLog(
  groupId: string,
  jobId: string | null,
  operation: string,
  status: string,
  details?: any,
  errorMessage?: string,
  durationMs?: number
) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("sync_logs")
    .insert({
      group_id: groupId,
      job_id: jobId,
      operation,
      status,
      details: details || {},
      error_message: errorMessage,
      duration_ms: durationMs,
      created_at: new Date().toISOString(),
    })
    .select()
    .single()

  if (error) {
    console.error("[v0] Failed to add sync log:", error)
    // Don't throw - logging failures shouldn't break main operations
    return null
  }
  
  return data
}

/**
 * Add sync log with automatic duration calculation
 */
export async function addSyncLogWithDuration(
  groupId: string,
  jobId: string | null,
  operation: string,
  status: string,
  startTime: Date,
  details?: any,
  errorMessage?: string
) {
  const durationMs = Date.now() - startTime.getTime()
  
  return await addSyncLog(
    groupId,
    jobId,
    operation,
    status,
    details,
    errorMessage,
    durationMs
  )
}

/**
 * Get sync logs for a group
 */
export async function getSyncLogs(
  groupId: string,
  options?: {
    limit?: number
    operation?: string
    status?: string
  }
) {
  const supabase = await createClient()

  let query = supabase
    .from("sync_logs")
    .select("*")
    .eq("group_id", groupId)
    .order("created_at", { ascending: false })

  if (options?.operation) {
    query = query.eq("operation", options.operation)
  }

  if (options?.status) {
    query = query.eq("status", options.status)
  }

  if (options?.limit) {
    query = query.limit(options.limit)
  }

  const { data, error } = await query

  if (error) throw error
  return data
}

/**
 * Get sync logs for a job
 */
export async function getJobSyncLogs(jobId: string) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("sync_logs")
    .select("*")
    .eq("job_id", jobId)
    .order("created_at", { ascending: true }) // Chronological order

  if (error) throw error
  return data
}

/**
 * Get error logs for a group
 */
export async function getErrorLogs(groupId: string, limit = 50) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("sync_logs")
    .select("*")
    .eq("group_id", groupId)
    .neq("status", "completed") // Get failed, error, etc.
    .order("created_at", { ascending: false })
    .limit(limit)

  if (error) throw error
  return data
}

/**
 * Count operations by status for analytics
 */
export async function getSyncLogStats(groupId: string) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("sync_logs")
    .select("operation, status")
    .eq("group_id", groupId)

  if (error) throw error

  const stats = {
    total: data.length,
    byOperation: {} as Record<string, number>,
    byStatus: {} as Record<string, number>,
    successRate: 0
  }

  data.forEach(log => {
    // Count by operation
    stats.byOperation[log.operation] = (stats.byOperation[log.operation] || 0) + 1
    
    // Count by status
    stats.byStatus[log.status] = (stats.byStatus[log.status] || 0) + 1
  })

  // Calculate success rate
  const successful = stats.byStatus['completed'] || 0
  const failed = (stats.byStatus['failed'] || 0) + (stats.byStatus['error'] || 0)
  const totalWithOutcome = successful + failed
  
  if (totalWithOutcome > 0) {
    stats.successRate = Math.round((successful / totalWithOutcome) * 100)
  }

  return stats
}
