// sync-manager.ts - COMPLETE UPDATED VERSION
import type { TelegramService } from "./telegram-service"
import { createClient } from "./supabase/server"
import * as queries from "./supabase/queries"
import { MTProtoService } from "./mtproto-implementation"
import {BigIntegerConverter} from './bigIntergerConverter'
import { Api } from 'telegram';
import { LiveSyncConfig, LiveSyncManager } from "./live-sync-manager"

export interface SyncJob {
  jobId: string
  sourceGroupId: string | number
  destGroupId: string | number
  method: "advanced" | "live" | "history"
  preserveSenders: boolean
  silentAdd: boolean
  userId: number
  createdAt: Date
  telegramNum?:string
}

export interface SyncProgress {
  jobId: string
  status: "pending" | "running" | "completed" | "failed" | "paused"
  totalMessages: number
  processedMessages: number
  failedMessages: number
  progress: number
  startedAt: Date
  estimatedEndTime?: Date
  error?: string
}

interface SyncJobOptions {
  useMTProto?: boolean
  preserveSenders?: boolean
  silentAdd?: boolean
  batchSize?: number
}

// Updated interfaces with BigInt
interface TelegramMember {
  id: bigint; // Changed from number to bigint
  username?: string;
  firstName?: string;
  lastName?: string;
  isAdmin: boolean;
  entity?: any; // Store the original entity for API calls
}

interface MTProtoMessage {
  id: bigint; // Changed from number to bigint
  peer_id: bigint; // Changed from number to bigint
  from_id: bigint; // Changed from number to bigint
  text?: string;
  media?: any;
  date: number;
}

interface MemberAddResult {
  userId: bigint; // Changed from number to bigint
  success: boolean;
  error?: string;
}

interface AddMembersResult {
  total: number;
  successful: number;
  failed: number;
  results: MemberAddResult[];
}

const activeJobs = new Map<string, SyncProgress>()
const syncJobQueue: SyncJob[] = []

export class SyncManager {
  private telegramService: TelegramService
  private mtprotoService?: MTProtoService
  private useMTProto: boolean
  private number: string

  constructor(telegramService: TelegramService, useMTProto = false, num = "") {
    this.telegramService = telegramService
    this.useMTProto = useMTProto
    this.number     = num

    if (useMTProto) {
      try {
        this.mtprotoService = this.initializeMTProto()
        console.log("[v0] MTProto service enabled for non-admin access")
      } catch (error) {
        console.warn("[v0] MTProto not available, falling back to Bot API:", error)
        this.useMTProto = false
      }
    }
  }

  async startLiveSync(
    jobId:any,
    sourceGroupId:number,
    destGroupId:number,
    syncReactions:boolean,
    syncEdits:boolean,
    syncDeletes:boolean,
    preserveSenders:boolean,
    time:number
  ){
    console.log("checks corrected!")
    if(!this.mtprotoService) {
      try {
        this.mtprotoService = this.initializeMTProto()
        console.log("[v0] MTProto service enabled for non-admin access")
      } catch (error) {
        console.warn("[v0] MTProto not available, falling back to Bot API:", error)
        this.useMTProto = false
        return;
      }
    }
    // Start a live sync
    const liveSyncManager = new LiveSyncManager(this.mtprotoService);

    const syncConfig: LiveSyncConfig = {
      sourceGroupId,  // Source group
      destGroupId,       // Destination group
      syncReactions,
      syncEdits,
      syncDeletes,
      preserveSenders
    };
    console.log("entering live sync ")
    const success = await liveSyncManager.startLiveSync(jobId, syncConfig);

    if (success) {
      console.log('Live sync started! All new messages will be copied automatically.');
    }
  
  }

   async stopLiveSync(
    jobId:any
  ){

    if(!this.mtprotoService) {
      try {
        this.mtprotoService = this.initializeMTProto()
        console.log("[v0] MTProto service enabled for non-admin access")
      } catch (error) {
        console.warn("[v0] MTProto not available, falling back to Bot API:", error)
        this.useMTProto = false
        return;
      }
    }
    // Stop a live sync
    const liveSyncManager = new LiveSyncManager(this.mtprotoService);

    const success = await liveSyncManager.stopLiveSync(jobId);

    if (success) {
      console.log('Live sync stopped! All new messages will not be copied automatically anymore.');
    }

    return success;
  
  }



  private initializeMTProto():  MTProtoService {
    const apiId = process.env.TELEGRAM_API_ID
    const apiHash = process.env.TELEGRAM_API_HASH
     const sessionString = process.env.TELEGRAM_SESSION_STRING

    if (!apiId || !apiHash) {
      throw new Error("TELEGRAM_API_ID and TELEGRAM_API_HASH environment variables are required for MTProto access")
    }

    try {
        if( this.number ){
          return new MTProtoService({
            apiId,
            apiHash,
            phoneNumber: this.number // Will auto-authenticate on first connect()
          });
        }
    }catch(e){
      return new MTProtoService({
        apiId,
        apiHash,
        // Add session management for persistence
        sessionString
      })
    }

    

    return new MTProtoService({
      apiId,
      apiHash,
      // Add session management for persistence
      sessionString
    })
  }

  /**
   * MAIN ENTRY POINT: Start clone job using MTProto instead of copyMessage
   */
  async startAdvancedClone(job: SyncJob, options: SyncJobOptions = {}): Promise<string> {
    const jobId = job.jobId

    const progress: SyncProgress = {
      jobId,
      status: "running",
      totalMessages: 0,
      processedMessages: 0,
      failedMessages: 0,
      progress: 0,
      startedAt: new Date(),
    }

    activeJobs.set(jobId, progress)

    console.log("[v0] Starting advanced clone:", {
      jobId,
      source: job.sourceGroupId,
      dest: job.destGroupId,
      useMTProto: this.useMTProto,
      method: job.method
    })

    // Use MTProto if available and enabled
    if (this.useMTProto && this.mtprotoService) {
      await this.processCloneWithCopy(job, progress, options)
    } else {
      await this.processCloneWithBotAPI(job, progress, options)
    }

    return jobId
  }

  /**
   * PROCESS WITH MTPROTO (NON-ADMIN ACCESS) - COMPLETE IMPLEMENTATION
   */
  private async processCloneWithMTProto(
    job: SyncJob, 
    progress: SyncProgress, 
    options: SyncJobOptions
  ): Promise<void> {
    try {
      console.log("[v0] Using MTProto for non-admin access...")

      // Step 1: Verify we can access the source group
      const sourceGroupId = Number(job.sourceGroupId)
      const destGroupId = Number(job.destGroupId)

      // Check membership (MTProto allows this for members)
      const isMember = await this.mtprotoService!.isMemberOfGroup(sourceGroupId)
      if (!isMember) {
        throw new Error(`Not a member of source group ${sourceGroupId}. MTProto requires membership.`)
      }

      console.log("[v0] Membership verified, fetching messages...")

      // Step 2: Get message history using MTProto
      // This works WITHOUT admin rights in source group
      const messageLimit = options.batchSize || 200
      const messages = await this.mtprotoService!.getHistory(sourceGroupId, messageLimit)
      
      if (!messages || messages.length === 0) {
        console.warn("[v0] No messages found in source group")
        progress.status = "completed"
        await this.updateJobProgress(job.jobId, progress)
        return
      }

      progress.totalMessages = messages.length
      await this.updateJobProgress(job.jobId, progress)

      console.log(`[v0] Found ${messages.length} messages, starting forward...`)

      // Step 3: Forward messages using MTProto (preserves senders)
      const messageIds = messages.map(msg => msg.id)
      
      // Forward in smaller batches to avoid rate limits
      const forwardBatchSize = 10
      let successfullyForwarded = 0

      for (let i = 0; i < messageIds.length; i += forwardBatchSize) {
        if (progress.status !== "running") {
          console.log("[v0] Job was paused or cancelled")
          break
        }

        const batch = messageIds.slice(i, i + forwardBatchSize)
        
        try {
          // MTProto forwardMessages preserves original senders
          const forwardedIds = await this.mtprotoService!.forwardMessages(
            sourceGroupId,
            destGroupId,
            batch
          )

          successfullyForwarded += forwardedIds.length
          progress.processedMessages = successfullyForwarded
          progress.progress = Math.floor((progress.processedMessages / progress.totalMessages) * 100)
          
          await this.updateJobProgress(job.jobId, progress)

          console.log(`[v0] Batch ${Math.floor(i / forwardBatchSize) + 1} completed:`, {
            processed: successfullyForwarded,
            total: progress.totalMessages,
            progress: `${progress.progress}%`
          })

          // Rate limiting - be gentle with Telegram
          await new Promise(resolve => setTimeout(resolve, 2000))

        } catch (batchError) {
          console.error(`[v0] Failed to forward batch ${Math.floor(i / forwardBatchSize) + 1}:`, batchError)
          progress.failedMessages += batch.length
          
          // Continue with next batch even if one fails
          continue
        }
      }

      // Step 4: Handle additional features
      if (job.silentAdd) {
        await this.handleMemberAddition(job)
      }

      // Step 5: Finalize
      progress.status = "completed"
      progress.progress = 100
      await this.updateJobProgress(job.jobId, progress)

      console.log("[v0] MTProto clone completed successfully", {
        totalProcessed: successfullyForwarded,
        failed: progress.failedMessages,
        successRate: `${((successfullyForwarded / progress.totalMessages) * 100).toFixed(1)}%`
      })

    } catch (error) {
      console.error("[v0] MTProto clone failed:", error)
      progress.status = "failed"
      progress.error = error instanceof Error ? error.message : "Unknown error"
      await this.updateJobProgress(job.jobId, progress)
      
      // Optional: Fallback to Bot API if MTProto fails
      if (options.useMTProto) {
        console.log("[v0] Attempting fallback to Bot API...")
        await this.processCloneWithBotAPI(job, progress, options)
      }
    }
  }

  /**
   * FALLBACK: Process with Bot API (requires admin rights)
   */
  private async processCloneWithBotAPI(
    job: SyncJob, 
    progress: SyncProgress, 
    options: SyncJobOptions
  ): Promise<void> {
    try {
      console.log("[v0] Using Bot API (admin access required)...")
      
      // This is your existing copyMessage logic, but we should minimize its use
      const chatInfo = await this.telegramService.getChat(job.sourceGroupId)
      const messageLimit = options.batchSize || 100

      progress.totalMessages = messageLimit

      // Get recent messages and copy them (admin required)
      let processedCount = 0
      const startMessageId = chatInfo.pinned_message?.message_id || 9999999

      for (let i = 0; i < messageLimit; i++) {
        if (progress.status !== "running") break

        try {
          const messageId = startMessageId - i
          
          // This requires admin rights in both groups
          const newMessageId = await this.telegramService.copyMessage({
            chat_id: job.destGroupId,
            from_chat_id: job.sourceGroupId,
            message_id: messageId,
          })

          processedCount++
          progress.processedMessages = processedCount
          progress.progress = Math.floor((processedCount / messageLimit) * 100)

          await this.updateJobProgress(job.jobId, progress)
          
          // Slower rate limiting for Bot API
          await new Promise(resolve => setTimeout(resolve, 500))

        } catch (error) {
          console.error(`[v0] Failed to copy message:`, error)
          progress.failedMessages++
        }
      }

      progress.status = "completed"
      await this.updateJobProgress(job.jobId, progress)

      console.log("[v0] Bot API clone completed", {
        processed: processedCount,
        failed: progress.failedMessages
      })

    } catch (error) {
      console.error("[v0] Bot API clone failed:", error)
      progress.status = "failed"
      progress.error = error instanceof Error ? error.message : "Unknown error"
      await this.updateJobProgress(job.jobId, progress)
    }
  }

  /**
   * Handle member addition (separate from message cloning)
   */
   private async handleMemberAddition(job: SyncJob): Promise<void> {
    try {
      console.log("[v0] Starting member addition process...");

      // Convert to BigInt
      const sourceGroupId = BigIntegerConverter.toBigInteger(job.sourceGroupId);
      const destGroupId = BigIntegerConverter.toBigInteger(job.destGroupId);

      // Check admin rights
      const hasAdminRights = await this.mtprotoService!.hasAdminRights(Number(destGroupId));
      
      if (!hasAdminRights) {
        console.warn("[v0] ❌ No admin rights in destination group");
        await this.handleMemberInvites(job);
        return;
      }

      // Get members (returns BigInt IDs)
      const sourceMembers = await this.mtprotoService!.getGroupMembers(Number(sourceGroupId));
      
      if (!sourceMembers || sourceMembers.length === 0) {
        console.warn("[v0] No members found in source group");
        return;
      }

      // Extract BigInt user IDs
      const userIds = sourceMembers.map(member => member.id).slice(0, 30);

      console.log(`[v0] Attempting to add ${userIds.length} members...`);

      const addResult = await this.mtprotoService!.addMembersToGroup(
        Number(destGroupId),
        userIds,
        {
          delayBetweenBatches: 15000
        }
      );

      console.log("[v0] Member addition completed:", {
        attempted: addResult.total,
        added: addResult.successful,
        failed: addResult.failed,
      });

      await this.logMemberAdditionResults(job, sourceMembers, addResult);

    } catch (error) {
      console.error("[v0] ❌ Member addition failed:", error);
    }
  }

    /**
   * Handle member invites when direct addition isn't possible
   */
  private async handleMemberInvites(job: SyncJob): Promise<void> {
    try {
      console.log("[v0] Starting member invitation process...");

      const sourceGroupId = BigIntegerConverter.toBigInteger(job.sourceGroupId);
      const destGroupId = BigIntegerConverter.toBigInteger(job.destGroupId);

      // Step 1: Create an invite link for the destination group
      console.log("[v0] Creating invite link for destination group...");
      const inviteLink = await this.createGroupInviteLink(destGroupId);
      
      if (!inviteLink) {
        console.error("[v0] ❌ Failed to create invite link");
        return;
      }

      console.log(`[v0] ✅ Invite link created: ${inviteLink}`);

      // Step 2: Get members from source group
      const sourceMembers = await this.mtprotoService!.getGroupMembers(
        BigIntegerConverter.toNumber(sourceGroupId)
      );
      
      if (!sourceMembers || sourceMembers.length === 0) {
        console.warn("[v0] No members found in source group for invites");
        return;
      }

      console.log(`[v0] Found ${sourceMembers.length} members to invite`);

      // Step 3: Send invitation messages to members
      const inviteMessage = this.createInviteMessage(inviteLink, job);
      
      const messageResult = await this.mtprotoService!.messageAllGroupMembers(
        BigIntegerConverter.toNumber(sourceGroupId),
        inviteMessage,
        {
          batchSize: 2,
          delayBetweenMessages: 10000, // 10 seconds between batches
          excludeAdmins: false
        }
      );

      // Step 4: Log invitation results
      await this.logInvitationResults(job, sourceMembers, messageResult, inviteLink);

      console.log("[v0] Member invitation process completed:", {
        totalMembers: sourceMembers.length,
        messagesSent: messageResult.successful,
        messagesFailed: messageResult.failed,
        inviteLink: inviteLink
      });

      // Step 5: Also post the invite link in the source group (if we have permissions)
      await this.postInviteInSourceGroup(sourceGroupId, inviteLink, job);

    } catch (error) {
      console.error("[v0] ❌ Member invitation process failed:", error);
    }
  }

  /**
   * Create an invite link for the group
   */
  private async createGroupInviteLink(groupId: bigInt.BigInteger): Promise<string | null> {
    try {
      // Using MTProto to create invite link
      const groupEntity = await this.mtprotoService!['client'].getEntity(
        BigIntegerConverter.toNumber(groupId)
      );
      
      const result = await this.mtprotoService!['client'].invoke(
        new Api.messages.ExportChatInvite({
          peer: groupEntity,
          expireDate: Math.floor(Date.now() / 1000) + (7 * 24 * 60 * 60), // 7 days
          usageLimit: 100,
          title: 'Group Migration Invite'
        })
      );

      // Handle different invite types
      if (result instanceof Api.ChatInviteExported) {
        return result.link; // This has the link property
      }  else {
        console.error('[v0] Unexpected invite type:', result?.className);
        return null;
      }

    } catch (error: any) {
      console.error("[v0] Failed to create invite link:", error.message);
      
      // Alternative: Try to get existing invite links
      try {
        const groupEntity = await this.mtprotoService!['client'].getEntity(
          BigIntegerConverter.toNumber(groupId)
        );
        
        const exportResult = await this.mtprotoService!['client'].invoke(
          new Api.messages.GetExportedChatInvites({
            peer: groupEntity,
            adminId: await this.mtprotoService!['client'].getMe(),
            limit: 1,
          })
        );

        if (exportResult.invites && exportResult.invites.length > 0) {
          return exportResult.invites[0].toString();
        }
      } catch (fallbackError) {
        console.error("[v0] Also failed to get existing invites:", fallbackError);
      }
      
      return null;
    }
  }

  /**
   * Create a formatted invitation message
   */
  private createInviteMessage(inviteLink: string, job: SyncJob): string {
    const baseMessage = `
🚀 **Group Migration Invitation**

You're invited to join our new group!

**Invitation Link:** ${inviteLink}

We're migrating from the previous group to this new improved one. Please join us there for future updates and discussions.

The invitation link will expire in 7 days.

Thank you! 👋
    `;

    // Customize message based on job type
    if (job.method === 'advanced') {
      return baseMessage + `\n\n_This is an automated invitation as part of our group upgrade process._`;
    } else if (job.method === 'live') {
      return baseMessage + `\n\n_This group will be actively maintained with real-time updates._`;
    }

    return baseMessage;
  }

  /**
   * Post invite link in source group (if we have permissions)
   */
  private async postInviteInSourceGroup(
    sourceGroupId: bigInt.BigInteger,
    inviteLink: string,
    job: SyncJob
  ): Promise<void> {
    try {
      console.log("[v0] Attempting to post invite link in source group...");

      const groupMessage = `
📢 **Important Announcement**

We've created a new improved group! 

Please join us here: ${inviteLink}

This group will be migrated soon, so make sure to join the new one to stay connected.

Thank you for being part of our community! 🙏
      `;

      await this.mtprotoService!.sendMessage(
        BigIntegerConverter.toNumber(sourceGroupId),
        groupMessage
      );

      console.log("[v0] ✅ Invite link posted in source group");

    } catch (error: any) {
      console.warn("[v0] Could not post invite link in source group:", error.message);
      // This is not critical - we already sent direct messages
    }
  }

  /**
   * Log invitation results to database
   */
  private async logInvitationResults(
    job: SyncJob,
    sourceMembers: TelegramMember[],
    messageResult: any,
    inviteLink: string
  ): Promise<void> {
    try {
      const supabase = await createClient();
      
      // Log each member's invitation status
      for (const member of sourceMembers) {
        const messageStatus = messageResult.results.find((r: any) => 
          r.userId && r.userId.equals && r.userId.equals(member.id)
        );

        await supabase
          .from('member_sync')
          .insert({
            group_id: job.jobId,
            source_member_id: Number(member.id),
            username: member.username,
            first_name: member.firstName,
            last_name: member.lastName,
            sync_method: 'invite',
            status: messageStatus?.success ? 'invited' : 'invite_failed',
            invite_link: inviteLink,
            error_message: messageStatus?.error,
            created_at: new Date().toISOString()
          });
      }

      // Also log the overall invitation event
      await supabase
        .from('sync_logs')
        .insert({
          group_id: job.jobId,
          operation: 'member_invitation',
          status: 'completed',
          details: {
            total_members: sourceMembers.length,
            invites_sent: messageResult.successful,
            invites_failed: messageResult.failed,
            invite_link: inviteLink
          },
          created_at: new Date().toISOString()
        });

      console.log("[v0] Invitation results logged to database");

    } catch (error) {
      console.error("[v0] Failed to log invitation results:", error);
    }
  }

  /**
   * Check if we can message members in the source group
   */
  private async canMessageSourceGroup(sourceGroupId: bigInt.BigInteger): Promise<boolean> {
    try {
      // Check if we're a member of the source group
      const isMember = await this.mtprotoService!.isMemberOfGroup(
        BigIntegerConverter.toNumber(sourceGroupId)
      );
      
      if (!isMember) {
        console.warn("[v0] Not a member of source group, cannot send messages");
        return false;
      }

      // Try to send a test message to ourselves to check permissions
      const me = await this.mtprotoService!['client'].getMe();
      await this.mtprotoService!.sendMessage(
        BigIntegerConverter.toNumber(sourceGroupId),
        "Test message to check permissions"
      );

      return true;

    } catch (error) {
      console.warn("[v0] Cannot send messages in source group:", error);
      return false;
    }
  }

  private async logMemberAdditionResults(
    job: SyncJob, 
    sourceMembers: TelegramMember[], 
    addResult: AddMembersResult|any
  ): Promise<void> {
    try {
      const supabase = await createClient();
      
      for (const result of addResult.results) {
        const sourceMember = sourceMembers.find(m => m.id === result.userId);
        
        await supabase
          .from('member_sync')
          .insert({
            group_id: job.jobId,
            source_member_id: BigIntegerConverter.toNumber(result.userId), // Convert back to number for database
            destination_member_id: result.success ? BigIntegerConverter.toNumber(result.userId) : null,
            username: sourceMember?.username,
            first_name: sourceMember?.firstName,
            last_name: sourceMember?.lastName,
            sync_method: 'direct_add',
            status: result.success ? 'added' : 'failed',
            error_message: result.error,
            created_at: new Date().toISOString()
          });
      }

    } catch (error) {
      console.error("[v0] Failed to log member addition results:", error);
    }
  }
  /**
   * Live mirroring with MTProto
   */
  async startLiveMirroring(job: SyncJob): Promise<string> {
    const jobId = job.jobId

    const progress: SyncProgress = {
      jobId,
      status: "running",
      totalMessages: 0,
      processedMessages: 0,
      failedMessages: 0,
      progress: 100, // Live sync is continuous
      startedAt: new Date(),
    }

    activeJobs.set(jobId, progress)

    console.log("[v0] Starting live mirror with MTProto:", {
      jobId,
      source: job.sourceGroupId,
      dest: job.destGroupId,
    })

    // Store in database for active sync tracking
    await this.updateJobProgress(jobId, progress)

    return jobId
  }

  /**
   * Updated webhook handler for MTProto
   */
  async handleWebhookUpdate(jobId: string, message: any): Promise<boolean> {
    const progress = activeJobs.get(jobId)
    if (!progress || progress.status !== "running") {
      console.warn("[v0] Invalid job state for webhook:", jobId)
      return false
    }

    try {
      const job = await queries.getCloneJob(jobId)
      if (!job) {
        console.warn("[v0] Job not found:", jobId)
        return false
      }

      // Use MTProto for live updates if available
      if (this.useMTProto && this.mtprotoService) {
        const forwardedIds = await this.mtprotoService.forwardMessages(
          message.chat.id,
          job.destination_group_id as number,
          [message.message_id]
        )
        
        console.log("[v0] Live message forwarded via MTProto:", {
          originalId: message.message_id,
          forwardedCount: forwardedIds.length
        })
      } else {
        // Fallback to Bot API
        await this.telegramService.copyMessage({
          chat_id: job.destination_group_id as number,
          from_chat_id: message.chat.id,
          message_id: message.message_id,
        })
      }

      progress.processedMessages++
      await this.updateJobProgress(jobId, progress)
      return true

    } catch (error) {
      console.error("[v0] Webhook processing error:", error)
      progress.failedMessages++
      return false
    }
  }

   /**
   * Process clone using COPY instead of FORWARD
   */
  private async processCloneWithCopy(
    job: SyncJob, 
    progress: SyncProgress, 
    options: SyncJobOptions
  ): Promise<void> {
    try {
      console.log("[v0] Using COPY method (no forwarded labels)...");

      const sourceGroupId = Number(job.sourceGroupId);
      const destGroupId = Number(job.destGroupId);

      // Verify membership
      const isMember = await this.mtprotoService!.isMemberOfGroup(sourceGroupId);
      if (!isMember) {
        throw new Error(`Not a member of source group ${sourceGroupId}`);
      }

      // Get message history
      
      const messageLimit = options.batchSize || 500;
      const messages = await this.mtprotoService!.getHistory(sourceGroupId, messageLimit);
      
      if (!messages || messages.length === 0) {
        console.warn("[v0] No messages found in source group");
        progress.status = "completed";
        await this.updateJobProgress(job.jobId, progress);
        return;
      }

      progress.totalMessages = messages.length;
      await this.updateJobProgress(job.jobId, progress);

      console.log(`[v0] Found ${messages.length} messages, starting COPY...`);

      // Use COPY instead of FORWARD
      const messageIds = messages.map(msg => msg.id);
      const copyResult = await this.mtprotoService!.copyMessages(
        sourceGroupId,
        destGroupId,
        messageIds,
        {
          batchSize: 5,
          delayBetweenMessages: 2000,
          preserveSenders: job.preserveSenders
        }
      );

      progress.processedMessages = copyResult.successful;
      progress.failedMessages = copyResult.failed;
      progress.progress = Math.floor((progress.processedMessages / progress.totalMessages) * 100);
      
      await this.updateJobProgress(job.jobId, progress);

      // Handle member addition if requested
     /* if (job.silentAdd) {
        await this.handleMemberAddition(job);
      } */

      progress.status = "completed";
      progress.progress = 100;
      await this.updateJobProgress(job.jobId, progress);

      console.log("[v0] COPY clone completed successfully", {
        copied: copyResult.successful,
        failed: copyResult.failed,
        successRate: `${((copyResult.successful / progress.totalMessages) * 100).toFixed(1)}%`
      });

      // Start live sync for this group
   /* await this.startLiveSync(
      /*groupId: group.id,
      `mirror-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      sourceGroupId,
      destGroupId,
      /*userId: group.userId,
       true, // or make this configurable
      true,
      true,
      true,
      5 * 60
    ) */

    } catch (error) {
      console.error("[v0] COPY clone failed:", error);
      progress.status = "failed";
      progress.error = error instanceof Error ? error.message : "Unknown error";
      await this.updateJobProgress(job.jobId, progress);
    }
  }

  // ... (keep your existing utility methods like updateJobProgress, getProgress, etc.)
  private async updateJobProgress(jobId: string, progress: SyncProgress): Promise<void> {
    try {
      await queries.updateCloneJobProgress(
        jobId,
        progress.processedMessages,
        progress.totalMessages,
        progress.status
      )
    } catch (error) {
      console.error("[v0] Failed to update job progress in database:", error)
    }
  }

  getProgress(jobId: string): SyncProgress | undefined {
    return activeJobs.get(jobId)
  }

  getAllProgress(): SyncProgress[] {
    return Array.from(activeJobs.values())
  }

  setPauseJob(jobId: string, paused: boolean): boolean {
    const progress = activeJobs.get(jobId)
    if (!progress) return false

    progress.status = paused ? "paused" : "running"
    return true
  }

  cancelJob(jobId: string): boolean {
    const progress = activeJobs.get(jobId)
    if (!progress) return false

    progress.status = "failed"
    console.log("[v0] Job cancelled:", jobId)
    return true
  }
}

// Export function to get sync manager
export function getSyncManager(useMTProto = false, num = ""): SyncManager {
  const { getTelegramService } = require("./telegram-service")
  return new SyncManager(getTelegramService(), useMTProto, num )
}