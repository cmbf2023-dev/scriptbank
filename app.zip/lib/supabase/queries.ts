import { createClient } from "./server"

// USER MANAGEMENT FUNCTIONS
export async function createUser(
  telegramId: number,
  data: {
    email?: string
    username?: string
    apiKey?: string
  }
) {
  const supabase = await createClient()

  const { data: user, error } = await supabase
    .from("users")
    .insert({
      telegram_id: telegramId,
      username: data.username,
      email: data.email,
      api_key: data.apiKey,
      is_active: true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .select()
    .single()

  if (error) {
    if (error.code === '23505') {
      console.log('User already exists, returning existing user')
      return await getUserByTelegramId(telegramId)
    }
    console.log("check the error: ", user );
    throw error
  }
  return user
}

export async function getUserById(userId: string) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("users")
    .select("*")
    .eq("id", userId)
    .single()

  if (error && error.code !== "PGRST116") throw error
  return data
}

export async function getGroup(userId: string) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("groups")
    .select("*")
    .eq("id", userId)
    .single()

  if (error && error.code !== "PGRST116") throw error
  return data
}

export async function getUserByTelegramId(telegramId: number) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("users")
    .select("*")
    .eq("telegram_id", telegramId)
    .single()

  if (error && error.code !== "PGRST116") throw error
  return data
}

export async function getUserByApiKey(apiKey: string) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("users")
    .select("*")
    .eq("api_key", apiKey)
    .eq("is_active", true)
    .single()

  if (error && error.code !== "PGRST116") throw error
  return data
}

export async function updateUser(userId: string, updates: any) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("users")
    .update({
      ...updates,
      updated_at: new Date().toISOString(),
    })
    .eq("id", userId)
    .select()
    .single()

  if (error) throw error
  return data
}

export async function createUserIfNotExists(
  telegramId: number,
  data: {
    email?: string
    username?: string
    apiKey?: string
  }
) {
  const supabase = await createClient()

  // Check if user already exists by telegram_id
  const existingUser = await getUserByTelegramId(telegramId)
  if (existingUser) {
    return existingUser
  }

  // Create new user
  return await createUser(telegramId, data)
}

// For Supabase Auth integration (if you're using both)
export async function createUserFromSupabaseAuth(
  supabaseUserId: string,
  telegramId: number,
  email?: string,
  username?: string
) {
  const supabase = await createClient()

  const { data: user, error } = await supabase
    .from("users")
    .insert({
      id: supabaseUserId, // Use the Supabase Auth user ID
      telegram_id: telegramId,
      email: email,
      username: username,
      is_active: true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .select()
    .single()

  if (error) {
    if (error.code === '23505') {
      return await getUserById(supabaseUserId)
    }
    throw error
  }
  return user
}

export async function createGroup(
  userId: string,
  data: {
    sourceGroupId: number
    destinationGroupId: number
    sourceGroupName?: string
    destinationGroupName?: string
    cloneMethod: string
    preserveSenders?: boolean
    silentAdd?: boolean
  },
) {
  const supabase = await createClient()

  // Verify user exists first
  const user = await getUserById(userId)
  if (!user) {
    throw new Error(`User ${userId} not found. Please create user profile first.`)
  }

  const { data: group, error } = await supabase
    .from("groups")
    .insert({
      user_id: userId,
      source_group_id: data.sourceGroupId,
      destination_group_id: data.destinationGroupId,
      source_group_name: data.sourceGroupName,
      destination_group_name: data.destinationGroupName,
      clone_method: data.cloneMethod,
      preserve_senders: data.preserveSenders ?? true,
      silent_add: data.silentAdd ?? true,
      status: 'inactive',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .select()
    .single()

  if (error) {
    if (error.code === '23505') {
      throw new Error('A group with this source and destination already exists for this user')
    }
    throw error
  }
  return group
}

export async function getGroupById(groupId: string) {
  const supabase = await createClient()

  const { data, error } = await supabase.from("groups").select("*").eq("id", groupId).single()

  if (error) throw error
  return data
}

export async function getUserGroups(userId: string) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("groups")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })

  if (error) throw error
  return data
}

export async function updateGroupStatus(groupId: string, status: string) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("groups")
    .update({ status, updated_at: new Date().toISOString() })
    .eq("id", groupId)
    .select()
    .single()

  if (error) throw error
  return data
}

export async function createCloneJob(groupId: string, method: string, totalItems: number) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("clone_jobs")
    .insert({
      group_id: groupId,
      method,
      status: "pending",
      total_items: totalItems,
      started_at: new Date().toISOString(),
    })
    .select()
    .single()

  if (error) throw error
  return data
}

export async function getCloneJob(jobId: string) {
  const supabase = await createClient()

  const { data, error } = await supabase.from("clone_jobs").select("*").eq("id", jobId).single()

  if (error && error.code !== "PGRST116") throw error
  return data
}

export async function getCloneJobProgress(jobId: string) {
  const supabase = await createClient()

  const { data, error } = await supabase.from("clone_jobs").select("*").eq("id", jobId).single()

  if (error) throw error
  return data
}

export async function updateCloneJobProgress(
  jobId: string,
  processedItems: number,
  totalItems: number,
  status?: string,
) {
  const supabase = await createClient()

  const progressPercent = totalItems > 0 ? Math.round((processedItems / totalItems) * 100) : 0

  const { data, error } = await supabase
    .from("clone_jobs")
    .update({
      processed_items: processedItems,
      progress_percent: progressPercent,
      status: status || "running",
      updated_at: new Date().toISOString(),
    })
    .eq("id", jobId)
    .select()
    .single()

  if (error) throw error
  return data
}

export async function completeCloneJob(jobId: string, success: boolean, errorMessage?: string) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("clone_jobs")
    .update({
      status: success ? "completed" : "failed",
      completed_at: new Date().toISOString(),
      error_message: errorMessage,
    })
    .eq("id", jobId)
    .select()
    .single()

  if (error) throw error
  return data
}

export async function getActiveSyncsBySourceGroup(sourceGroupId: number) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("clone_jobs")
    .select(`
      *,
      groups (
        source_group_id,
        destination_group_id,
        silent_add
      )
    `)
    .eq("status", "running")
    .eq("groups.source_group_id", sourceGroupId)

  if (error) throw error

  // Flatten the response
  return (data || []).map((job: any) => ({
    id: job.id,
    destination_group_id: job.groups.destination_group_id,
    method: job.method,
    silent_add: job.groups.silent_add,
    processed_messages: job.processed_items,
  }))
}

export async function addSyncLog(
  groupId: string,
  jobId: string | null,
  operation: string,
  status: string,
  details?: any,
  errorMessage?: string,
) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("sync_logs")
    .insert({
      group_id: groupId,
      job_id: jobId,
      operation,
      status,
      details: details || {},
      error_message: errorMessage,
    })
    .select()
    .single()

  if (error) throw error
  return data
}

export async function getGroupAnalytics(groupId: string) {
  const supabase = await createClient()

  const [messages, members, jobs] = await Promise.all([
    supabase.from("messages").select("id").eq("group_id", groupId),
    supabase.from("members").select("id").eq("group_id", groupId),
    supabase.from("clone_jobs").select("*").eq("group_id", groupId),
  ])

  return {
    messageCount: messages.data?.length || 0,
    memberCount: members.data?.length || 0,
    jobs: jobs.data || [],
  }
}

export async function getRecentActivities(userId: string, limit = 20) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("sync_logs")
    .select("*, groups(source_group_name, destination_group_name)")
    .eq("groups.user_id", userId)
    .order("created_at", { ascending: false })
    .limit(limit)

  if (error) throw error
  return data
}

export async function getUserSettings(userId: string) {
  const supabase = await createClient()

  const { data, error } = await supabase.from("settings").select("*").eq("user_id", userId).single()

  if (error && error.code !== "PGRST116") throw error
  return data
}

export async function updateUserSettings(userId: string, updates: any) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("settings")
    .upsert({
      user_id: userId,
      ...updates,
      updated_at: new Date().toISOString(),
    })
    .select()
    .single()

  if (error) throw error
  return data
}

export async function createMessageMapping(jobId: string, sourceMessageId: number, destinationMessageId: number) {
  const supabase = await createClient()

  const { error } = await supabase.from("messages").insert({
    job_id: jobId,
    source_message_id: sourceMessageId,
    destination_message_id: destinationMessageId,
    synced_at: new Date().toISOString(),
  })

  if (error) throw error
}

export async function getMessageMappings(sourceGroupId: number, messageId: number) {
  const supabase = await createClient()

  const { data, error } = await supabase.from("messages").select("*").eq("source_message_id", messageId)

  if (error) throw error
  return data || []
}

export async function updateMessageMapping(mappingId: string, newMessageId: number) {
  const supabase = await createClient()

  const { error } = await supabase.from("messages").update({ destination_message_id: newMessageId }).eq("id", mappingId)

  if (error) throw error
}
