// utils/biginteger-converter.ts
import bigInt from 'big-integer';
import { Api } from 'telegram';

export class BigIntegerConverter {
  /**
   * Convert number/string to BigInteger for Telegram IDs
   */
  static toBigInteger(value: number | string | bigint): bigInt.BigInteger {
    if (typeof value === 'number') {
      return bigInt(value);
    }
    
    if (typeof value === 'string') {
      // Handle string numbers and remove any non-numeric characters
      const numericString = value.replace(/[^\d-]/g, '');
      return bigInt(numericString);
    }
    
    if (typeof value === 'bigint') {
      return bigInt(value.toString());
    }
    
    throw new Error(`Cannot convert ${typeof value} to BigInteger`);
  }

  /**
   * Convert BigInteger back to number (with safety check)
   */
  static toNumber(value: bigInt.BigInteger): number {
    if (value.greater(Number.MAX_SAFE_INTEGER) || value.lesser(Number.MIN_SAFE_INTEGER)) {
      throw new Error(`BigInteger value ${value} is too large for JavaScript Number`);
    }
    return value.toJSNumber();
  }

  /**
   * Convert BigInteger to string
   */
  static toString(value: bigInt.BigInteger): string {
    return value.toString();
  }

  /**
   * Check if a number is safe to convert
   */
  static isSafeNumber(value: number): boolean {
    return value <= Number.MAX_SAFE_INTEGER && value >= Number.MIN_SAFE_INTEGER;
  }

  /**
   * Convert Telegram peer ID to BigInteger
   */
  static peerToBigInteger(peer: any): bigInt.BigInteger {
    if (peer instanceof Api.PeerUser) {
      return this.toBigInteger(peer.userId as unknown as string);
    } else if (peer instanceof Api.PeerChat) {
      return this.toBigInteger(peer.chatId as unknown as string);
    } else if (peer instanceof Api.PeerChannel) {
      return this.toBigInteger(peer.channelId as unknown as string);
    } else {
      throw new Error(`Unsupported peer type: ${peer?.className}`);
    }
  }
}