/**
 * Webhook Validator - Validates Telegram Bot API webhook signatures
 */

import crypto from 'crypto'

export function validateWebhookSignature(
  body: string,
  signature: string,
  secret: string
): boolean {
  const hmac = crypto.createHmac('sha256', secret)
  hmac.update(body)
  const hash = hmac.digest('hex')

  return hash === signature
}

export function generateWebhookToken(): string {
  return crypto.randomBytes(32).toString('hex')
}

export function validateWebhookUrl(url: string): boolean {
  try {
    const parsed = new URL(url)
    return parsed.protocol === 'https:' || parsed.hostname === 'localhost'
  } catch {
    return false
  }
}
