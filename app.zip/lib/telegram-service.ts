/**
 * Telegram Service - Handles MTProto API interactions
 * Wraps Telegram Bot API calls for group cloning operations
 */

interface TelegramMessage {
  message_id: number
  from?: {
    id: number
    first_name: string
    last_name?: string
    username?: string
  }
  text?: string
  caption?: string
  photo?: Array<any>
  document?: any
  video?: any
  audio?: any
  voice?: any
  reply_to_message_id?: number
}

interface CopyMessageParams {
  chat_id: number | string
  from_chat_id: number | string
  message_id: number
  caption?: string
  parse_mode?: string
}

export class TelegramService {
  private botToken: string
  private apiBaseUrl = "https://api.telegram.org"

  constructor(botToken: string) {
    if (!botToken) {
      throw new Error("Bot token is required")
    }
    this.botToken = botToken
  }

  /**
   * Copy message from source group to destination (preserves original sender)
   * Based on official Telegram Bot API: https://core.telegram.org/bots/api#copymessage
   */
  async copyMessage(params: CopyMessageParams): Promise<number> {
    try {
      const requestBody: any = {
        chat_id: Number(params.chat_id), // Must be integer, not string
        from_chat_id: Number(params.from_chat_id), // Must be integer
        message_id: Number(params.message_id), // Must be integer
        disable_notification: true, // Added - silent copy by default
      }

      // Add optional parameters if provided
      if (params.caption) requestBody["caption"] = params.caption
      if (params.parse_mode) requestBody["parse_mode"] = params.parse_mode

      console.log("[v0] copyMessage request:", requestBody)

      const response = await fetch(`${this.apiBaseUrl}/bot${this.botToken}/copyMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(requestBody),
      })

      const data = await response.json()

      if (!data.ok) {
        console.error("[v0] Telegram API Error Response:", {
          errorCode: data.error_code,
          description: data.description,
          parameters: data.parameters,
        })
        throw new Error(`Telegram API Error (${data.error_code}): ${data.description}`)
      }

      console.log("[v0] Message copied successfully:", data.result.message_id)
      return data.result.message_id
    } catch (error) {
      console.error("[v0] Copy message error:", error)
      throw error
    }
  }

  /**
   * Forward message from source to destination
   */
  async forwardMessage(chatId: number | string, fromChatId: number | string, messageId: number): Promise<number> {
    try {
      const requestBody = {
        chat_id: Number(chatId),
        from_chat_id: Number(fromChatId),
        message_id: Number(messageId),
        disable_notification: true, // Silent forward
      }

      console.log("[v0] forwardMessage request:", requestBody)

      const response = await fetch(`${this.apiBaseUrl}/bot${this.botToken}/forwardMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(requestBody),
      })

      const data = await response.json()

      if (!data.ok) {
        console.error("[v0] Forward message API error:", data.description)
        throw new Error(`Telegram API Error: ${data.description}`)
      }

      return data.result.message_id
    } catch (error) {
      console.error("[v0] Forward message error:", error)
      throw error
    }
  }

  /**
   * Add user to group silently (without notification)
   */
  async addChatMember(chatId: number | string, userId: number, options?: { expires_in?: number }): Promise<boolean> {
    try {
      const response = await fetch(`${this.apiBaseUrl}/bot${this.botToken}/addChatMember`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
          user_id: userId,
          ...options,
        }),
      })

      if (!response.ok) {
        throw new Error(`API Error: ${response.statusText}`)
      }

      const data = await response.json()
      return data.ok
    } catch (error) {
      console.error("[v0] Add chat member error:", error)
      throw error
    }
  }

  /**
   * Get chat members count
   */
  async getChatMembersCount(chatId: number | string): Promise<number> {
    try {
      const response = await fetch(`${this.apiBaseUrl}/bot${this.botToken}/getChatMembersCount`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
        }),
      })

      if (!response.ok) {
        throw new Error(`API Error: ${response.statusText}`)
      }

      const data = await response.json()
      if (!data.ok) {
        throw new Error(`Telegram API Error: ${data.description}`)
      }

      return data.result
    } catch (error) {
      console.error("[v0] Get chat members count error:", error)
      throw error
    }
  }

  /**
   * Get chat info
   */
  async getChat(chatId: number | string): Promise<any> {
    try {
      const response = await fetch(`${this.apiBaseUrl}/bot${this.botToken}/getChat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: `${chatId}`,
        }),
      })

      console.log("get chat original response: ", response )

      if (!response.ok) {
        throw new Error(`API Error: ${response.statusText}`)
      }

      const data = await response.json()
      if (!data.ok) {
        throw new Error(`Telegram API Error: ${data.description}`)
      }

      return data.result
    } catch (error) {
      console.error("[v0] Get chat error:", error)
      throw error
    }
  }

  /**
   * Delete message from chat
   */
  async deleteMessage(chatId: number | string, messageId: number): Promise<boolean> {
    try {
      const response = await fetch(`${this.apiBaseUrl}/bot${this.botToken}/deleteMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
          message_id: messageId,
        }),
      })

      if (!response.ok) {
        throw new Error(`API Error: ${response.statusText}`)
      }

      const data = await response.json()
      return data.ok
    } catch (error) {
      console.error("[v0] Delete message error:", error)
      throw error
    }
  }

  /**
   * Send message to chat
   */
  async sendMessage(chatId: number | string, text: string, options?: any): Promise<number> {
    try {
      const response = await fetch(`${this.apiBaseUrl}/bot${this.botToken}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
          text,
          ...options,
        }),
      })

      if (!response.ok) {
        throw new Error(`API Error: ${response.statusText}`)
      }

      const data = await response.json()
      if (!data.ok) {
        throw new Error(`Telegram API Error: ${data.description}`)
      }

      return data.result.message_id
    } catch (error) {
      console.error("[v0] Send message error:", error)
      throw error
    }
  }

  /**
   * Get chat members list (for advanced member syncing)
   */
  async getChatMembers(chatId: number | string, offset = 0, limit = 100): Promise<any[]> {
    try {
      // Note: Bot API has limitations for getting members
      // This is a placeholder - for production use TDLib or Telethon
      console.log("[v0] getChatMembers called - requires TDLib for full access")
      return []
    } catch (error) {
      console.error("[v0] Get chat members error:", error)
      throw error
    }
  }
}

export function getTelegramService(): TelegramService {
  const botToken = process.env.TELEGRAM_BOT_TOKEN
  if (!botToken) {
    throw new Error("TELEGRAM_BOT_TOKEN environment variable is not set")
  }
  return new TelegramService(botToken)
}
