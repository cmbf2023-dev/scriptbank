"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, CheckCircle, AlertCircle } from "lucide-react"

interface AuthCredentialsPopupProps {
  isOpen: boolean
  title: string
  description?: string
  placeholder?: string
  isPassword?: boolean
  onSubmit: (value: string, phone: string) => void | Promise<void>
  onCancel?: () => void
  isLoading?: boolean
  error?: string
  phone?:string
}

export function AuthCredentialsPopup({
  isOpen,
  title,
  description,
  placeholder = "Enter OTP from Telegram",
  isPassword = false,
  onSubmit,
  onCancel,
  isLoading = false,
  error,
  phone
}: AuthCredentialsPopupProps) {
  const [inputValue, setInputValue] = useState("")
  const [localError, setLocalError] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  if (!isOpen) return null

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!inputValue.trim()) {
      setLocalError("This field is required")
      return
    }

    setIsSubmitting(true)
    setLocalError(null)

    try {
      await onSubmit(inputValue, `${phone}`)
      setInputValue("")
       setIsSubmitting(false)
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : "An error occurred")
       setIsSubmitting(false)
    } finally {
      setIsSubmitting(false)
    }
  }

  const displayError = error || localError

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>{title}</CardTitle>
          {description && <CardDescription>{description}</CardDescription>}
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {displayError && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{displayError}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Input
                type={isPassword ? "password" : "text"}
                placeholder={placeholder}
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                disabled={isSubmitting || isLoading}
                autoFocus
                className="font-mono"
              />
            </div>

            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setInputValue("")
                  setLocalError(null)
                  onCancel?.()
                }}
                disabled={isSubmitting || isLoading}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting || isLoading || !inputValue.trim()} className="flex-1">
                {isSubmitting || isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Submit
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
