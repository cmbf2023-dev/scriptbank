'use client'

import { useState } from 'react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Zap, Radio, History } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import {AuthCredentialsPopup} from '../auth-popup'

export function CloningTab() {
  const [activeMethod, setActiveMethod] = useState('advanced')
  const [sourceGroupId, setSourceGroupId] = useState('')
  const [destGroupId, setDestGroupId] = useState('')//setTelegramAccount
  const [telegramNum, setTelegramAccount] = useState('')
  const [preserveSenders, setPreserveSenders] = useState(true)
  const [silentAdd, setSilentAdd] = useState(true)
  const [isLoading, setIsLoading] = useState(false)
  const [isStopping, setIsStopping] = useState(false)
  const [isOpen, setIsOpen] = useState(false)
  const [isLoad, setIsLoad] = useState(false)
  const [title, setTitle] = useState('Enter OTP')
  const [description, setDescription] = useState('This is a code that will be recieved in your Telegram App where you have this number active')
  const { toast } = useToast()


  const handleSubmit = async (inputValue:string, phone:string) =>{
    setIsLoad(true);
    const options = { credentialType:"otp", value:inputValue, phone };

    try {
      const response = await fetch('/api/auth', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(options),
      });
      
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      setIsOpen(false)
      
      const result = await response.json();
      return result;
    } catch (error) {
      console.error('Error:', error);
    }
  }

  const handleCancel = ()=>{
    setIsLoad(false);
    setIsOpen(false);
  }


  const methods = [
    {
      id: 'advanced',
      title: 'Advanced Clone',
      description: 'Preserve original sender names with copyMessage method',
      icon: Zap,
      features: ['Original senders preserved', 'Silent user addition', 'Message forwarding', 'Reply chains intact'],
    },
    {
      id: 'live',
      title: 'Live Mirroring',
      description: 'Real-time synchronization with webhook-based forwarding',
      icon: Radio,
      features: ['Instant message sync', 'Automatic member sync', 'Real-time reactions', '24/7 monitoring'],
    },
    {
      id: 'history',
      title: 'History Cloning',
      description: 'Batch process historical messages and member data',
      icon: History,
      features: ['Batch processing', 'Schedule cloning', 'Selective history', 'Progress tracking'],
    },
  ]

  const handleStartCloning = async () => {
    if (!sourceGroupId || !destGroupId) {
      toast({
        title: 'Error',
        description: 'Both source and destination group IDs are required',
        variant: 'destructive',
      })
      return
    }

    setIsLoading(true)
    setIsOpen(true)

    try {
      const endpoint = `/api/groups/clone/${activeMethod}`
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sourceGroupId,
          destGroupId,
          telegramNum,
          preserveSenders,
          silentAdd,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        toast({
          title: 'Success',
          description: `Cloning job started: ${data.jobId}`,
        })
        //setSourceGroupId('')
        //setDestGroupId('')
        console.log("Final clone data: ", data )

      } else {
        throw new Error('Failed to start cloning')
        
      }
      
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to start cloning',
        variant: 'destructive',
      })
    }/* finally {
      setIsLoading(false)
    }*/
  }

  const handleStopCloning = async ()=>{
    setIsStopping(true)

     const endpoint = `/api/stop`
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sourceGroupId,
        destGroupId,
      }),
    })

    console.log("Stopping cloned")

    if (response.ok) {
      const data = await response.json()
      toast({
        title: 'Success',
        description: `Stopped Cloning: ${data.groupId}`,
      })
      setIsLoading(false)
      setIsStopping(false)
      setSourceGroupId('')
      setDestGroupId('')
      console.log("Final clone data: ", data )

    } else {
      //setIsLoading(false)
      setIsStopping(false)
      toast({
        title: 'Error',
        description: `Failed to stop Cloning`,
        variant: "destructive"
      })   
    }

  }

  return (
    <>
    <div className="p-8 space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-card-foreground mb-2">Clone Group</h2>
        <p className="text-muted-foreground">Choose your cloning method</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {methods.map((method) => {
          const Icon = method.icon
          return (
            <Card
              key={method.id}
              className={`p-6 cursor-pointer transition-all ${
                activeMethod === method.id ? 'ring-2 ring-primary bg-primary/5' : ''
              }`}
              onClick={() => setActiveMethod(method.id)}
            >
              <div className="flex items-start gap-3 mb-4">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold text-card-foreground">{method.title}</h3>
                  <p className="text-xs text-muted-foreground mt-1">{method.description}</p>
                </div>
              </div>
              <ul className="space-y-2">
                {method.features.map((feature) => (
                  <li key={feature} className="text-xs text-muted-foreground flex items-center gap-2">
                    <span className="w-1 h-1 bg-primary rounded-full"></span>
                    {feature}
                  </li>
                ))}
              </ul>
            </Card>
          )
        })}
      </div>

      <Card className="p-8">
        <h3 className="text-xl font-bold text-card-foreground mb-6">Configure Clone</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-card-foreground mb-2">Source Group ID</label>
            <input
              type="text"
              placeholder="Enter source Telegram group ID"
              value={sourceGroupId}
              onChange={(e) => setSourceGroupId(e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-border bg-secondary text-card-foreground placeholder-muted-foreground"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-card-foreground mb-2">Destination Group ID</label>
            <input
              type="text"
              placeholder="Enter destination Telegram group ID"
              value={destGroupId}
              onChange={(e) => setDestGroupId(e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-border bg-secondary text-card-foreground placeholder-muted-foreground"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-card-foreground mb-2">Telegram Number</label>
            <input
              type="text"
              placeholder="Enter Your Telegram Acccount Number"
              value={telegramNum}
              onChange={(e) => setTelegramAccount(e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-border bg-secondary text-card-foreground placeholder-muted-foreground"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="preserve"
                checked={preserveSenders}
                onChange={(e) => setPreserveSenders(e.target.checked)}
                className="rounded"
              />
              <label htmlFor="preserve" className="text-sm text-card-foreground">
                Preserve sender names
              </label>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="silent"
                checked={silentAdd}
                onChange={(e) => setSilentAdd(e.target.checked)}
                className="rounded"
              />
              <label htmlFor="silent" className="text-sm text-card-foreground">
                Silent user addition
              </label>
            </div>
          </div>
          <Button
            onClick={handleStartCloning}
            disabled={isLoading}
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90 mt-6"
          >
            {isLoading ? 'Starting...' : 'Start Cloning Process'}
          </Button>
          {isLoading && <Button
            onClick={handleStopCloning}
            className="w-full bg-destructive text-destructive-foreground hover:bg-destructive/80 active:bg-destructive/70 mt-6 transition-colors"
          >
            {isStopping ? 'Stopping...' : 'Stop Cloning Process'}
          </Button>}
        </div>
      </Card>
    </div>
    <AuthCredentialsPopup isOpen={isOpen} title={title} description={description} onSubmit={handleSubmit} onCancel={handleCancel} isLoading={isLoad} phone={telegramNum}/>
    </>
  )
}
