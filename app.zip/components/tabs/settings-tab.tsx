'use client'

import { useState } from 'react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Key, Bell, Shield, Database, Copy, Check } from 'lucide-react'

export function SettingsTab() {
  const [copied, setCopied] = useState<string | null>(null)


  const settings = [
    { icon: Key, title: 'API Keys', description: 'Manage Telegram Bot API credentials' },
    { icon: Bell, title: 'Notifications', description: 'Configure alert preferences' },
    { icon: Shield, title: 'Security', description: 'Manage authentication and permissions' },
    { icon: Database, title: 'Data', description: 'Backup and manage cloned data' },
  ]

  const handleCopyToken = (token: string) => {
    navigator.clipboard.writeText(token)
    setCopied(token)
    setTimeout(() => setCopied(null), 2000)
  }

  return (
    <div className="p-8 space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-card-foreground mb-2">Settings & Configuration</h2>
        <p className="text-muted-foreground">Manage platform settings and security preferences</p>
      </div>

      {/* Settings Cards */}
      <div className="space-y-4">
        {settings.map((setting) => {
          const Icon = setting.icon
          return (
            <Card key={setting.title} className="p-6 flex items-center justify-between hover:bg-secondary/50 transition-colors">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <Icon className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold text-card-foreground">{setting.title}</h3>
                  <p className="text-sm text-muted-foreground">{setting.description}</p>
                </div>
              </div>
              <Button variant="outline">Configure</Button>
            </Card>
          )
        })}
      </div>

      {/* API Keys Section */}
      <Card className="p-6">
        <h3 className="font-bold text-lg mb-6 text-card-foreground flex items-center gap-2">
          <Key className="h-5 w-5 text-primary" />
          API Configuration
        </h3>

        <div className="space-y-6">
          {/* Telegram Bot Token */}
          <div>
            <label className="block text-sm font-medium text-card-foreground mb-3">Telegram Bot Token</label>
            <div className="flex gap-2">
              <div className="flex-1 p-3 bg-secondary rounded-lg border border-border">
                <input
                  type="password"
                  defaultValue="6089234156:AAF2xnY4n3Hv7j2m9K5L8pQ1w4x9z2c5"
                  readOnly
                  className="w-full bg-transparent text-card-foreground text-sm font-mono outline-none"
                />
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleCopyToken('6089234156:AAF2xnY4n3Hv7j2m9K5L8pQ1w4x9z2c5')}
                className="flex items-center gap-2"
              >
                {copied === '6089234156:AAF2xnY4n3Hv7j2m9K5L8pQ1w4x9z2c5' ? (
                  <>
                    <Check className="h-4 w-4" />
                    Copied
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4" />
                    Copy
                  </>
                )}
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Get your token from @BotFather on Telegram. Keep it secret and never share.
            </p>
          </div>

          {/* Webhook URL */}
          <div>
            <label className="block text-sm font-medium text-card-foreground mb-3">Webhook URL</label>
            <div className="flex gap-2">
              <div className="flex-1 p-3 bg-secondary rounded-lg border border-border">
                <input
                  type="text"
                  defaultValue="https://your-app.vercel.app/api/webhooks/telegram"
                  readOnly
                  className="w-full bg-transparent text-card-foreground text-sm font-mono outline-none"
                />
              </div>
              <Button variant="outline" size="sm">Register</Button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              This URL will receive real-time updates from Telegram.
            </p>
          </div>

          {/* Webhook Token */}
          <div>
            <label className="block text-sm font-medium text-card-foreground mb-3">Webhook Security Token</label>
            <div className="flex gap-2">
              <div className="flex-1 p-3 bg-secondary rounded-lg border border-border">
                <input
                  type="password"
                  defaultValue="sk_live_51234567890abcdefghijklmnopqrstuv"
                  readOnly
                  className="w-full bg-transparent text-card-foreground text-sm font-mono outline-none"
                />
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleCopyToken('sk_live_51234567890abcdefghijklmnopqrstuv')}
                className="flex items-center gap-2"
              >
                {copied === 'sk_live_51234567890abcdefghijklmnopqrstuv' ? (
                  <>
                    <Check className="h-4 w-4" />
                    Copied
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4" />
                    Copy
                  </>
                )}
              </Button>
            </div>
            <Button variant="outline" size="sm" className="mt-3 w-full">
              Regenerate Token
            </Button>
          </div>
        </div>
      </Card>

      {/* Notification Settings */}
      <Card className="p-6">
        <h3 className="font-bold text-lg mb-6 text-card-foreground flex items-center gap-2">
          <Bell className="h-5 w-5 text-primary" />
          Notification Preferences
        </h3>

        <div className="space-y-4">
          {[
            { label: 'Clone completion', description: 'Notify when a cloning process completes' },
            { label: 'Sync failures', description: 'Alert on message sync failures' },
            { label: 'High error rate', description: 'Notify when error rate exceeds 2%' },
            { label: 'Member limit reached', description: 'Alert when member additions fail' },
          ].map((item, i) => (
            <div key={i} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
              <div>
                <p className="text-sm font-medium text-card-foreground">{item.label}</p>
                <p className="text-xs text-muted-foreground">{item.description}</p>
              </div>
              <input type="checkbox" defaultChecked className="rounded w-4 h-4" />
            </div>
          ))}
        </div>
      </Card>

      {/* Security Settings */}
      <Card className="p-6">
        <h3 className="font-bold text-lg mb-6 text-card-foreground flex items-center gap-2">
          <Shield className="h-5 w-5 text-primary" />
          Security & Access
        </h3>

        <div className="space-y-4">
          <div className="p-4 bg-secondary rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-sm font-medium text-card-foreground">Two-Factor Authentication</p>
                <p className="text-xs text-muted-foreground">Secure your account with 2FA</p>
              </div>
              <span className="text-xs px-2 py-1 bg-green-500/20 text-green-700 dark:text-green-400 rounded-full">
                Enabled
              </span>
            </div>
            <Button variant="outline" size="sm" className="w-full">
              Manage 2FA
            </Button>
          </div>

          <div className="p-4 bg-secondary rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-sm font-medium text-card-foreground">Active Sessions</p>
                <p className="text-xs text-muted-foreground">Manage your login sessions</p>
              </div>
              <span className="text-xs px-2 py-1 bg-blue-500/20 text-blue-700 dark:text-blue-400 rounded-full">
                1 Session
              </span>
            </div>
            <Button variant="outline" size="sm" className="w-full">
              View Sessions
            </Button>
          </div>

          <div className="p-4 bg-secondary rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-sm font-medium text-card-foreground">API Access Control</p>
                <p className="text-xs text-muted-foreground">Manage API key permissions</p>
              </div>
            </div>
            <Button variant="outline" size="sm" className="w-full">
              Configure Access
            </Button>
          </div>
        </div>
      </Card>

      {/* Data Management */}
      <Card className="p-6">
        <h3 className="font-bold text-lg mb-6 text-card-foreground flex items-center gap-2">
          <Database className="h-5 w-5 text-primary" />
          Data Management
        </h3>

        <div className="space-y-4">
          <div className="p-4 bg-secondary rounded-lg flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-card-foreground">Backup Data</p>
              <p className="text-xs text-muted-foreground">Export all cloning logs and configurations</p>
            </div>
            <Button variant="outline" size="sm">
              Export
            </Button>
          </div>

          <div className="p-4 bg-secondary rounded-lg flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-card-foreground">Clear Cache</p>
              <p className="text-xs text-muted-foreground">Clear all temporary sync data</p>
            </div>
            <Button variant="outline" size="sm">
              Clear
            </Button>
          </div>

          <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-lg flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-card-foreground">Delete All Data</p>
              <p className="text-xs text-muted-foreground">Permanently delete all cloning history</p>
            </div>
            <Button variant="outline" size="sm" className="text-destructive hover:text-destructive">
              Delete
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}
