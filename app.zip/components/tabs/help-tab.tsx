'use client'

import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { HelpCircle, BookOpen, AlertCircle, ExternalLink } from 'lucide-react'

export function HelpTab() {

  const faqs = [
    {
      question: 'How do I get my Telegram Bot Token?',
      answer: 'Visit @BotFather on Telegram, use /newbot command, and follow the instructions. You\'ll receive a unique token that looks like: 6089234156:AAF2xnY4n3Hv7j2m9K5L8pQ1w4x9z2c5',
    },
    {
      question: 'What is the maximum number of groups I can clone?',
      answer: 'You can manage up to 20 simultaneous group clones. For higher limits, contact our support team. Each clone can sync up to 200,000 messages.',
    },
    {
      question: 'How real-time is the Live Mirroring?',
      answer: 'Live Mirroring uses webhook-based synchronization for near-instant message replication. Typical latency is under 500ms, with 99%+ of messages synced within 2 seconds.',
    },
    {
      question: 'Do I need special permissions in the source group?',
      answer: 'Yes, your bot must have administrator privileges in the source group. It needs permissions to read messages, manage members, and copy messages.',
    },
    {
      question: 'Can I stop a clone at any time?',
      answer: 'Yes, you can pause or cancel any active clone from the Groups tab. Paused clones can be resumed, while cancelled clones cannot be recovered.',
    },
    {
      question: 'Are there any rate limits?',
      answer: 'Telegram enforces rate limits on API calls. We automatically handle throttling. Most operations complete within normal speed, but batch operations may take longer.',
    },
  ]

  const resources = [
    { title: 'Telegram Bot API Documentation', url: 'https://core.telegram.org/bots/api' },
    { title: 'Getting Started Guide', url: '#' },
    { title: 'Advanced Configuration', url: '#' },
    { title: 'Troubleshooting Guide', url: '#' },
  ]

  return (
    <div className="p-8 space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-card-foreground mb-2">Help & Support</h2>
        <p className="text-muted-foreground">Find answers and get started with Telegram Group Cloner</p>
      </div>

      {/* Getting Started Banner */}
      <Card className="p-6 bg-primary/5 border border-primary/20">
        <div className="flex gap-4">
          <AlertCircle className="h-5 w-5 text-primary flex-shrink-0 mt-1" />
          <div>
            <h3 className="font-bold text-card-foreground mb-2">Getting Started</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Before cloning your first group, ensure you have your Telegram Bot Token from @BotFather. Create a bot, configure API settings, and you're ready to start cloning!
            </p>
            <Button size="sm" className="bg-primary text-primary-foreground">
              View Setup Guide
            </Button>
          </div>
        </div>
      </Card>

      {/* FAQ Section */}
      <div>
        <h3 className="font-bold text-xl text-card-foreground mb-4">Frequently Asked Questions</h3>
        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <Card key={i} className="p-6">
              <h4 className="font-bold text-card-foreground flex items-center gap-2 mb-3">
                <HelpCircle className="h-4 w-4 text-primary flex-shrink-0" />
                {faq.question}
              </h4>
              <p className="text-sm text-muted-foreground">{faq.answer}</p>
            </Card>
          ))}
        </div>
      </div>

      {/* Resources Section */}
      <div>
        <h3 className="font-bold text-xl text-card-foreground mb-4">Resources & Documentation</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {resources.map((resource, i) => (
            <Card key={i} className="p-6 hover:bg-secondary/50 transition-colors cursor-pointer">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <BookOpen className="h-5 w-5 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-bold text-card-foreground mb-1">{resource.title}</h4>
                    <p className="text-xs text-muted-foreground">Click to open documentation</p>
                  </div>
                </div>
                <ExternalLink className="h-4 w-4 text-muted-foreground" />
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Support Section */}
      <Card className="p-6 bg-secondary">
        <div className="flex gap-6 items-start">
          <AlertCircle className="h-6 w-6 text-primary flex-shrink-0" />
          <div className="flex-1">
            <h3 className="font-bold text-card-foreground mb-3">Need More Help?</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Our support team is here to help. Contact us for technical assistance, questions about your account, or feature requests.
            </p>
            <div className="flex gap-3 flex-wrap">
              <Button variant="outline" size="sm">
                Email Support
              </Button>
              <Button variant="outline" size="sm">
                Live Chat
              </Button>
              <Button variant="outline" size="sm">
                Community Forum
              </Button>
            </div>
          </div>
        </div>
      </Card>

      {/* Status & System Info */}
      <Card className="p-6">
        <h3 className="font-bold text-lg mb-4 text-card-foreground">System Status</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-secondary rounded-lg">
            <p className="text-muted-foreground text-sm mb-2">API Status</p>
            <p className="text-green-600 dark:text-green-400 font-bold flex items-center gap-2">
              <span className="w-2 h-2 bg-green-500 rounded-full"></span>
              Operational
            </p>
          </div>
          <div className="p-4 bg-secondary rounded-lg">
            <p className="text-muted-foreground text-sm mb-2">Webhook Service</p>
            <p className="text-green-600 dark:text-green-400 font-bold flex items-center gap-2">
              <span className="w-2 h-2 bg-green-500 rounded-full"></span>
              Active
            </p>
          </div>
          <div className="p-4 bg-secondary rounded-lg">
            <p className="text-muted-foreground text-sm mb-2">Database</p>
            <p className="text-green-600 dark:text-green-400 font-bold flex items-center gap-2">
              <span className="w-2 h-2 bg-green-500 rounded-full"></span>
              Connected
            </p>
          </div>
        </div>
      </Card>
    </div>
  )
}
