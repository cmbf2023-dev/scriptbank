# Environment Variables Setup Guide

Complete step-by-step guide to obtain and configure the three required environment variables for the Telegram Group Cloning Platform.

---

## Overview

Your application requires three critical environment variables:

| Variable | Purpose | Type | Required |
|----------|---------|------|----------|
| `TELEGRAM_BOT_TOKEN` | Authenticate with Telegram Bot API | String | ✅ Yes |
| `NEXT_PUBLIC_APP_URL` | Your application's public URL | String | ✅ Yes |
| `WEBHOOK_TOKEN` | Secure webhook authentication | String | ✅ Yes |

---

## 1. TELEGRAM_BOT_TOKEN

### What is it?
A unique authentication token that identifies your bot to Telegram's servers. It's like a password for your bot - **keep it secret!**

**Format:** `123456789:ABCDefGHIjklMnoPqrsTuVwxYz`

### How to Get It

#### Step 1: Open BotFather
1. Open Telegram app
2. Search for `@BotFather` (the official Telegram bot manager)
3. Click to open the chat

#### Step 2: Create New Bot
1. Send the message: `/newbot`
2. BotFather will ask: **"Alright! New bot. How are we going to call it?"**
3. Enter your bot's display name (e.g., `Telegram Group Cloner`)

#### Step 3: Set Bot Username
1. BotFather will ask: **"Good. Now let's choose a username for your bot."**
2. Enter a username (must be unique, ends with "bot", e.g., `telegram_group_cloner_bot`)
3. Must be between 5-32 characters

#### Step 4: Copy Token
1. BotFather responds with your token:
   \`\`\`
   Done! Congratulations on your new bot. You'll find it at 
   t.me/your_bot_username. You can now add a description, 
   about section and profile picture for your bot, see /help 
   for a list of commands. By the way, when you've finished 
   creating your bot and stop using it, remember to stop it 
   with the /stop command.

   Use this token to access the HTTP API:
   123456789:ABCDefGHIjklMnoPqrsTuVwxYz
   \`\`\`

2. **COPY THIS TOKEN** - this is your `TELEGRAM_BOT_TOKEN`

### Configuration

#### Add to .env.local
\`\`\`env
TELEGRAM_BOT_TOKEN=123456789:ABCDefGHIjklMnoPqrsTuVwxYz
\`\`\`

#### Test Token Validity
\`\`\`bash
# Run this command to verify your token works
curl -X GET "https://api.telegram.org/bot123456789:ABCDefGHIjklMnoPqrsTuVwxYz/getMe"

# Should return:
# {"ok":true,"result":{"id":123456789,"is_bot":true,"first_name":"Your Bot Name","username":"your_bot_username"}}
\`\`\`

#### Set Bot Permissions (In BotFather)

Back in BotFather chat, run these commands to configure your bot:

\`\`\`
/setprivacy
# Select your bot → enabled (default settings are fine)

/setcommands
# Select your bot → then send:
clone - Start cloning groups
status - Check clone status
help - Get help information
\`\`\`

#### Configure Bot Settings (In BotFather)

\`\`\`
/setdefault_administrator_rights
# Select your bot → yes (allows bot to manage groups)

/setuserpic
# Optional: Upload a profile picture for your bot
\`\`\`

### Important Notes

⚠️ **Security Best Practices:**
- Never commit this token to GitHub
- Never share it publicly
- If exposed, immediately run `/newbot` in BotFather to regenerate
- Keep it in `.env.local` (which is in `.gitignore`)

---

## 2. NEXT_PUBLIC_APP_URL

### What is it?
The public URL where your application is hosted. This tells Telegram where to send webhooks and where users access your dashboard.

**Examples:**
- Development: `http://localhost:3000`
- Production: `https://my-telegram-cloner.vercel.app`
- Custom domain: `https://cloner.mycompany.com`

### Why "NEXT_PUBLIC"?
- `NEXT_PUBLIC_` prefix means this variable is exposed to the browser
- It's safe to expose because it's just a URL, not a secret
- Needed by frontend to make API calls

### How to Set It

#### For Local Development
\`\`\`env
NEXT_PUBLIC_APP_URL=http://localhost:3000
\`\`\`

#### For Vercel Deployment
\`\`\`env
NEXT_PUBLIC_APP_URL=https://your-project-name.vercel.app
\`\`\`

#### For Custom Domain
\`\`\`bash
# 1. Buy domain (e.g., Namecheap, GoDaddy)
# 2. Add to Vercel in Project Settings → Domains
# 3. Update environment variable:
NEXT_PUBLIC_APP_URL=https://yourdomain.com
\`\`\`

### How to Get Your URL

#### Option 1: Development (Local)
\`\`\`bash
# When running npm run dev, your app is at:
NEXT_PUBLIC_APP_URL=http://localhost:3000
\`\`\`

#### Option 2: Vercel Deployment
1. Go to [vercel.com](https://vercel.com)
2. Click your project
3. Go to "Deployments" tab
4. Copy the deployment URL (e.g., `https://my-project-abc123.vercel.app`)
5. Set as `NEXT_PUBLIC_APP_URL`

#### Option 3: Custom Domain
1. Buy domain (e.g., `telegram-cloner.com`)
2. Add to Vercel in Project Settings → Domains
3. Set `NEXT_PUBLIC_APP_URL=https://telegram-cloner.com`

### Test URL Configuration
\`\`\`bash
# Visit your URL and verify it loads the dashboard
curl https://your-app-url.com

# Should return HTML (your Next.js app)
\`\`\`

### Important Notes

⚠️ **Must be publicly accessible:**
- Cannot be `localhost` for production (webhooks won't work)
- Must use `https://` in production (Telegram requires HTTPS)
- Must be a valid, resolvable domain

---

## 3. WEBHOOK_TOKEN

### What is it?
A secret token that secures communication between Telegram and your application. It prevents malicious actors from faking updates from Telegram.

**Format:** Any long random string (minimum 32 characters recommended)

**Examples:**
- ✅ Good: `wsdxcfvgbhnjmksxdcfvgbhnjmdecfvgbhnjmk`
- ✅ Good: `webhook_token_my_super_secret_abc123xyz789`
- ❌ Bad: `123` (too short, predictable)
- ❌ Bad: `password` (too simple)

### How to Generate It

#### Using Node.js / OpenSSL
\`\`\`bash
# Generate a random token
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# Output example:
# a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6
\`\`\`

#### Using Online Generator (Quick)
1. Visit [uuidgenerator.net/uuid/v4](https://www.uuidgenerator.net/uuid/v4)
2. Click "Generate" multiple times
3. Copy the result (or use another random generator)

#### Using Command Line
\`\`\`bash
# macOS / Linux
openssl rand -hex 32

# Windows (PowerShell)
[System.Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
\`\`\`

### How to Use It

#### 1. Add to .env.local
\`\`\`env
WEBHOOK_TOKEN=a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6
\`\`\`

#### 2. Register Webhook with Telegram
After deploying your app:

\`\`\`bash
# Set webhook URL with secret token
curl -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook" \
  -H "Content-Type: application/json" \
  -d "{
    \"url\": \"https://your-app-url.com/api/webhooks/telegram\",
    \"secret_token\": \"${WEBHOOK_TOKEN}\"
  }"

# Replace:
# - ${TELEGRAM_BOT_TOKEN} with your bot token
# - https://your-app-url.com with your NEXT_PUBLIC_APP_URL
# - ${WEBHOOK_TOKEN} with your webhook token
\`\`\`

#### 3. Verify Webhook is Set
\`\`\`bash
curl -X GET "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getWebhookInfo"

# Should return:
# {
#   "ok": true,
#   "result": {
#     "url": "https://your-app-url.com/api/webhooks/telegram",
#     "has_custom_certificate": false,
#     "pending_update_count": 0,
#     "last_error_date": 0
#   }
# }
\`\`\`

### Security Best Practices

⚠️ **Token Security:**
- Generate a new token each deployment
- Never commit to version control
- Store in `.env.local` (gitignored)
- Change token if you suspect compromise
- Use minimum 32 characters

⚠️ **Webhook Validation:**
The app validates that incoming webhooks have the correct `X-Telegram-Bot-API-Secret-Token` header. This is automatic in `app/api/webhooks/telegram/route.ts`.

---

## Complete .env.local Example

Here's a complete example of all three variables together:

\`\`\`env
# Telegram Configuration
TELEGRAM_BOT_TOKEN=123456789:ABCDefGHIjklMnoPqrsTuVwxYz

# Application URL
NEXT_PUBLIC_APP_URL=http://localhost:3000

# Webhook Security Token
WEBHOOK_TOKEN=a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6
\`\`\`

---

## Environment Variables by Stage

### Development (Local)
\`\`\`env
TELEGRAM_BOT_TOKEN=123456789:ABCDefGHIjklMnoPqrsTuVwxYz
NEXT_PUBLIC_APP_URL=http://localhost:3000
WEBHOOK_TOKEN=dev_token_12345678901234567890
\`\`\`

### Staging
\`\`\`env
TELEGRAM_BOT_TOKEN=123456789:ABCDefGHIjklMnoPqrsTuVwxYz
NEXT_PUBLIC_APP_URL=https://staging-app.vercel.app
WEBHOOK_TOKEN=staging_token_12345678901234567890
\`\`\`

### Production
\`\`\`env
TELEGRAM_BOT_TOKEN=987654321:XYZabcDefGHIjklMnoPqrsTuVwxYz
NEXT_PUBLIC_APP_URL=https://telegram-cloner.com
WEBHOOK_TOKEN=prod_token_98765432109876543210
\`\`\`

**Note:** Use different bot tokens for different environments (create separate bots in BotFather).

---

## Setting Variables on Vercel

### Method 1: Dashboard UI
1. Go to [vercel.com/dashboard](https://vercel.com/dashboard)
2. Select your project
3. Click "Settings" → "Environment Variables"
4. Add each variable:
   - Key: `TELEGRAM_BOT_TOKEN`
   - Value: Your token
   - Environments: Select Production, Preview, Development
5. Click "Save"
6. Repeat for other two variables
7. Deploy → new environment variables take effect

### Method 2: Vercel CLI
\`\`\`bash
# Install Vercel CLI
npm install -g vercel

# Set environment variables
vercel env add TELEGRAM_BOT_TOKEN
vercel env add NEXT_PUBLIC_APP_URL
vercel env add WEBHOOK_TOKEN

# Deploy with new variables
vercel deploy --prod
\`\`\`

### Method 3: GitHub Integration
If connected to GitHub:
1. Update `.env.local` locally
2. Push to GitHub
3. In Vercel Dashboard, manually add variables (recommended)
4. GitHub doesn't automatically sync .env files for security

---

## Troubleshooting

### Issue: "Invalid token" error
\`\`\`
Error: {"ok":false,"error_code":401,"description":"Unauthorized"}

Solution:
1. Double-check token from BotFather (no spaces)
2. Verify it's the full token including number and colon
3. Test with the getMe command shown above
4. If still failing, generate new token: /newbot in BotFather
\`\`\`

### Issue: Webhook not receiving updates
\`\`\`
Error: No updates received from Telegram

Solutions:
1. Verify NEXT_PUBLIC_APP_URL is public (not localhost)
2. Ensure URL uses https:// (Telegram requires HTTPS)
3. Check webhook is registered: getWebhookInfo command
4. Verify WEBHOOK_TOKEN matches in code
5. Test webhook manually:
   curl -X POST "https://your-url/api/webhooks/telegram" \
     -H "X-Telegram-Bot-API-Secret-Token: your-token" \
     -H "Content-Type: application/json" \
     -d "{\"update_id\":1,\"message\":{\"text\":\"test\"}}"
\`\`\`

### Issue: "Cannot add members" or "Bot doesn't have permission"
\`\`\`
Solutions:
1. Add bot as ADMIN to both source and destination groups
2. Bot must have "Delete messages" permission (required for copyMessage)
3. Bot must have "Add new members" permission
4. Destination group must allow bots to add members
5. Groups must not be restricted (no closed/invitation-only groups)

To set bot as admin:
1. Open group
2. Click group name
3. Go to "Administrators"
4. Add your bot
5. Give it necessary permissions
\`\`\`

### Issue: Local development webhook won't work
\`\`\`
Error: Telegram can't reach http://localhost:3000

Solution (use ngrok for local testing):
1. Install ngrok: https://ngrok.com
2. Run: ngrok http 3000
3. Get public URL from ngrok output (e.g., https://abc123.ngrok.io)
4. Update NEXT_PUBLIC_APP_URL=https://abc123.ngrok.io
5. Now webhooks will work locally for testing

Or just use Vercel deployment for webhook testing.
\`\`\`

---

## Security Checklist

Before going to production, verify:

- [ ] `TELEGRAM_BOT_TOKEN` is not in GitHub (check .gitignore)
- [ ] `WEBHOOK_TOKEN` is 32+ characters
- [ ] All three variables are set in Vercel
- [ ] `NEXT_PUBLIC_APP_URL` uses HTTPS
- [ ] Webhook is registered with Telegram (getWebhookInfo)
- [ ] Bot is admin in source and destination groups
- [ ] No sensitive data logged in browser console
- [ ] .env.local exists but not committed

---

## Quick Start Checklist

- [ ] Create bot with @BotFather → get `TELEGRAM_BOT_TOKEN`
- [ ] Deploy app → get `NEXT_PUBLIC_APP_URL`
- [ ] Generate random string → create `WEBHOOK_TOKEN`
- [ ] Add all three to `.env.local`
- [ ] Run `npm run dev` locally
- [ ] Test endpoints work
- [ ] Deploy to Vercel
- [ ] Set variables in Vercel dashboard
- [ ] Register webhook with Telegram
- [ ] Test production webhook

---

## Next Steps

After setting up these variables:
1. Run the database schema migration (see README.md)
2. Start the development server: `npm run dev`
3. Visit http://localhost:3000
4. Add your first group pair to clone
5. Test the cloning functionality

For more details, see [README.md](./README.md)
