-- Telegram Group Cloning Platform Schema

CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  telegram_id BIGINT UNIQUE NOT NULL,
  username VARCHAR(255),
  email VARCHAR(255) UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS groups (
  id SERIAL PRIMARY KEY,
  user_id INT NOT NULL REFERENCES users(id),
  source_group_id BIGINT NOT NULL,
  destination_group_id BIGINT NOT NULL,
  source_group_name VARCHAR(255),
  destination_group_name VARCHAR(255),
  clone_method VARCHAR(50) DEFAULT 'advanced',
  status VARCHAR(50) DEFAULT 'active',
  preserve_senders BOOLEAN DEFAULT TRUE,
  silent_add BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, source_group_id, destination_group_id)
);

CREATE TABLE IF NOT EXISTS messages (
  id SERIAL PRIMARY KEY,
  group_id INT NOT NULL REFERENCES groups(id),
  source_message_id BIGINT NOT NULL,
  destination_message_id BIGINT,
  sender_id BIGINT,
  sender_name VARCHAR(255),
  message_text TEXT,
  message_type VARCHAR(50),
  synced_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS members (
  id SERIAL PRIMARY KEY,
  group_id INT NOT NULL REFERENCES groups(id),
  telegram_user_id BIGINT NOT NULL,
  username VARCHAR(255),
  first_name VARCHAR(255),
  last_name VARCHAR(255),
  joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sync_logs (
  id SERIAL PRIMARY KEY,
  group_id INT NOT NULL REFERENCES groups(id),
  status VARCHAR(50),
  total_messages BIGINT,
  synced_messages BIGINT,
  error_message TEXT,
  started_at TIMESTAMP,
  completed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS webhooks (
  id SERIAL PRIMARY KEY,
  user_id INT NOT NULL REFERENCES users(id),
  webhook_url VARCHAR(500) NOT NULL UNIQUE,
  webhook_token VARCHAR(255) NOT NULL UNIQUE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_telegram_id ON users(telegram_id);
CREATE INDEX idx_groups_user_id ON groups(user_id);
CREATE INDEX idx_groups_status ON groups(status);
CREATE INDEX idx_messages_group_id ON messages(group_id);
CREATE INDEX idx_members_group_id ON members(group_id);
CREATE INDEX idx_sync_logs_group_id ON sync_logs(group_id);
CREATE INDEX idx_webhooks_user_id ON webhooks(user_id);
